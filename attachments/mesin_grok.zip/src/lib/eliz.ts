export type Candle = {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
};

export type MondayRange = {
  weekStart: number;
  high: number;
  low: number;
  mid: number;
  size: number;
  sizePct: number;
};

export type Zone = {
  top: number;
  bottom: number;
  mid: number;
  kind: "supply" | "demand" | "mid";
  label: string;
  strength: number;
};

export type Setup = {
  direction: "long" | "short";
  score: number;
  reason: string;
  entryLow: number;
  entryHigh: number;
  invalidation: number;
  target: number | null;
  riskPct: number;
};

export type Analysis = {
  symbol: string;
  price: number;
  source: string;
  recommendation: string;
  recClass: "long" | "short" | "none";
  posRange: string;
  posBoxes: string;
  mondayRange: MondayRange | null;
  boxes: Zone[];
  setups: Setup[];
  notes: string[];
  candles: Candle[];
};

function atr(candles: Candle[], period = 14) {
  if (candles.length < 2) return 0;
  const trs: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const h = candles[i].high;
    const l = candles[i].low;
    const pc = candles[i - 1].close;
    trs.push(Math.max(h - l, Math.abs(h - pc), Math.abs(l - pc)));
  }
  const slice = trs.slice(-period);
  return slice.reduce((a, b) => a + b, 0) / slice.length;
}

function mondayUTC(ts: number) {
  const d = new Date(ts);
  const day = d.getUTCDay();
  const diff = day === 0 ? -6 : 1 - day;
  return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + diff);
}

export function calcMondayRange(candles: Candle[]): MondayRange | null {
  const groups = new Map<number, Candle[]>();
  for (const c of candles) {
    if (new Date(c.time).getUTCDay() !== 1) continue;
    const key = mondayUTC(c.time);
    const arr = groups.get(key) ?? [];
    arr.push(c);
    groups.set(key, arr);
  }
  const keys = [...groups.keys()].sort((a, b) => a - b);
  for (let i = keys.length - 1; i >= 0; i--) {
    const bars = groups.get(keys[i])!;
    if (!bars.length) continue;
    let high = -Infinity;
    let low = Infinity;
    for (const b of bars) {
      if (b.high > high) high = b.high;
      if (b.low < low) low = b.low;
    }
    return {
      weekStart: keys[i],
      high,
      low,
      mid: (high + low) / 2,
      size: high - low,
      sizePct: low > 0 ? ((high - low) / low) * 100 : 0,
    };
  }
  return null;
}

export function detectBoxes(candles: Candle[], maxBoxes = 3): Zone[] {
  if (candles.length < 20) return [];
  const left = 3;
  const right = 3;
  const swings: { price: number; kind: "supply" | "demand" }[] = [];
  for (let i = left; i < candles.length - right; i++) {
    let isHigh = true;
    let isLow = true;
    for (let j = i - left; j <= i + right; j++) {
      if (j === i) continue;
      if (candles[j].high >= candles[i].high) isHigh = false;
      if (candles[j].low <= candles[i].low) isLow = false;
    }
    if (isHigh) swings.push({ price: candles[i].high, kind: "supply" });
    if (isLow) swings.push({ price: candles[i].low, kind: "demand" });
  }
  if (!swings.length) return [];
  const zone = atr(candles) * 0.45 || candles[candles.length - 1].close * 0.004;
  swings.sort((a, b) => b.price - a.price);
  const used = new Set<number>();
  const clusters: typeof swings[] = [];
  for (let i = 0; i < swings.length; i++) {
    if (used.has(i)) continue;
    const c = [swings[i]];
    used.add(i);
    for (let j = i + 1; j < swings.length; j++) {
      if (used.has(j)) continue;
      if (Math.abs(swings[i].price - swings[j].price) <= zone * 2) {
        c.push(swings[j]);
        used.add(j);
      }
    }
    clusters.push(c);
  }
  let boxes: Zone[] = clusters.map((c) => {
    const prices = c.map((x) => x.price);
    const supplies = c.filter((x) => x.kind === "supply").length;
    const top = Math.max(...prices) + zone * 0.4;
    const bottom = Math.min(...prices) - zone * 0.4;
    const kind: Zone["kind"] = supplies >= c.length / 2 ? "supply" : "demand";
    return { top, bottom, mid: (top + bottom) / 2, kind, label: kind, strength: c.length };
  });
  boxes.sort((a, b) => b.strength - a.strength);
  boxes = boxes.slice(0, maxBoxes);
  boxes.sort((a, b) => b.top - a.top);
  if (boxes.length >= 3) {
    boxes[0] = { ...boxes[0], kind: "supply", label: "Supply / resistance" };
    boxes[1] = { ...boxes[1], kind: "mid", label: "Mid / no-trade" };
    boxes[2] = { ...boxes[2], kind: "demand", label: "Demand / support" };
  } else if (boxes.length === 2) {
    boxes[0] = { ...boxes[0], kind: "supply", label: "Supply / resistance" };
    boxes[1] = { ...boxes[1], kind: "demand", label: "Demand / support" };
  } else if (boxes.length === 1) {
    boxes[0] = { ...boxes[0], label: "Key level" };
  }
  return boxes;
}

function detectSweep(
  candles: Candle[],
  level: number,
  direction: "below" | "above",
  lookback = 40,
) {
  const recent = candles.slice(-lookback);
  const minPen = 0.08;
  if (direction === "below") {
    let sweepIdx = -1;
    let sweepPrice = 0;
    for (let i = 0; i < recent.length; i++) {
      if (recent[i].low < level) {
        const pen = ((level - recent[i].low) / level) * 100;
        if (pen >= minPen) {
          sweepIdx = i;
          sweepPrice = recent[i].low;
        }
      }
    }
    if (sweepIdx < 0) return null;
    for (let i = sweepIdx; i < recent.length; i++) {
      if (recent[i].close > level) {
        const barsOut = i - sweepIdx;
        if (barsOut > 8) return null;
        return { sweepPrice, pen: ((level - sweepPrice) / level) * 100, barsOut };
      }
    }
  } else {
    let sweepIdx = -1;
    let sweepPrice = 0;
    for (let i = 0; i < recent.length; i++) {
      if (recent[i].high > level) {
        const pen = ((recent[i].high - level) / level) * 100;
        if (pen >= minPen) {
          sweepIdx = i;
          sweepPrice = recent[i].high;
        }
      }
    }
    if (sweepIdx < 0) return null;
    for (let i = sweepIdx; i < recent.length; i++) {
      if (recent[i].close < level) {
        const barsOut = i - sweepIdx;
        if (barsOut > 8) return null;
        return { sweepPrice, pen: ((sweepPrice - level) / level) * 100, barsOut };
      }
    }
  }
  return null;
}

export function analyzeMarket(args: {
  symbol: string;
  source: string;
  entry: Candle[];
  hourly: Candle[];
  daily: Candle[];
}): Analysis {
  const { symbol, source, entry, hourly, daily } = args;
  const price = entry[entry.length - 1]?.close ?? 0;
  const mr = calcMondayRange(hourly);
  const boxes = detectBoxes(daily.length >= 30 ? daily : entry, 3);
  const setups: Setup[] = [];
  const notes: string[] = [];

  if (mr) {
    const longSig = detectSweep(entry, mr.low, "below");
    if (longSig) {
      const stop = longSig.sweepPrice * 0.998;
      setups.push({
        direction: "long",
        score: Math.min(100, Math.round(70 + Math.min(20, longSig.pen * 8) + (longSig.barsOut <= 3 ? 10 : 0))),
        reason: "Sweep Monday Low lalu reclaim ke dalam range.",
        entryLow: mr.low,
        entryHigh: mr.low + mr.size * 0.15,
        invalidation: stop,
        target: mr.high,
        riskPct: price ? (Math.abs(price - stop) / price) * 100 : 0,
      });
    }
    const shortSig = detectSweep(entry, mr.high, "above");
    if (shortSig) {
      const stop = shortSig.sweepPrice * 1.002;
      setups.push({
        direction: "short",
        score: Math.min(100, Math.round(70 + Math.min(20, shortSig.pen * 8) + (shortSig.barsOut <= 3 ? 10 : 0))),
        reason: "Break Monday High, deviation, lalu kembali masuk range.",
        entryLow: mr.high - mr.size * 0.15,
        entryHigh: mr.high,
        invalidation: stop,
        target: mr.low,
        riskPct: price ? (Math.abs(stop - price) / price) * 100 : 0,
      });
    }
  }

  for (const b of boxes) {
    if (b.kind === "demand") {
      const s = detectSweep(entry, b.bottom, "below");
      if (s) {
        setups.push({
          direction: "long",
          score: Math.min(95, 65 + b.strength * 3),
          reason: `Sweep + reclaim di ${b.label}.`,
          entryLow: b.bottom,
          entryHigh: b.mid,
          invalidation: s.sweepPrice * 0.997,
          target: null,
          riskPct: price ? (Math.abs(price - s.sweepPrice) / price) * 100 : 0,
        });
      }
    }
    if (b.kind === "supply") {
      const s = detectSweep(entry, b.top, "above");
      if (s) {
        setups.push({
          direction: "short",
          score: Math.min(95, 65 + b.strength * 3),
          reason: `Deviation + reclaim di ${b.label}.`,
          entryLow: b.mid,
          entryHigh: b.top,
          invalidation: s.sweepPrice * 1.003,
          target: null,
          riskPct: price ? (Math.abs(s.sweepPrice - price) / price) * 100 : 0,
        });
      }
    }
  }

  setups.sort((a, b) => b.score - a.score);

  let posRange = "Tidak ada Monday Range";
  if (mr) {
    if (price > mr.high) posRange = "Di atas Monday High";
    else if (price < mr.low) posRange = "Di bawah Monday Low";
    else if (Math.abs(price - mr.mid) / mr.size < 0.28) posRange = "Di dalam range, dekat tengah — no-trade";
    else posRange = "Di dalam range, dekat ekstrem";
  }

  let posBoxes = "Tidak ada box";
  if (boxes.length) {
    const inside = boxes.find((b) => price >= b.bottom && price <= b.top);
    if (inside) posBoxes = `Di dalam ${inside.label}`;
    else {
      const hi = Math.max(...boxes.map((b) => b.top));
      const lo = Math.min(...boxes.map((b) => b.bottom));
      if (price > hi) posBoxes = "Di atas semua box";
      else if (price < lo) posBoxes = "Di bawah semua box";
      else posBoxes = "Di antara box — middle of nowhere";
    }
  }

  const inMiddle = posRange.includes("tengah") || posBoxes.includes("antara") || posBoxes.includes("Mid");
  let recommendation = "NO TRADE — duduk diam";
  let recClass: Analysis["recClass"] = "none";
  if (inMiddle) {
    recommendation = "NO TRADE — tengah range";
    notes.push("Harga di tengah range. Sitting on hands is also a position.");
  }
  const good = setups.filter((s) => s.score >= 72);
  if (good.length && !inMiddle) {
    const best = good[0];
    recommendation = `${best.direction === "long" ? "LONG" : "SHORT"} potensial — skor ${best.score}`;
    recClass = best.direction;
    notes.push(best.reason);
  } else if (!good.length) {
    notes.push("Belum ada sweep + deviation + reclaim yang jelas.");
    notes.push("Tunggu harga datang ke Monday High/Low atau box, lalu lihat reaksi.");
  }
  notes.push("Entry hanya 1%. Disiplin dan risk management yang menentukan.");
  notes.push("Usulan: risk ≤ 0,75% ekuitas per ide, maksimal 4 ide, tahan paling lama 7 hari.");

  return {
    symbol,
    price,
    source,
    recommendation,
    recClass,
    posRange,
    posBoxes,
    mondayRange: mr,
    boxes,
    setups,
    notes,
    candles: entry.slice(-90),
  };
}
