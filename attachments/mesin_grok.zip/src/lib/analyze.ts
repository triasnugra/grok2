import { createServerFn } from "@tanstack/react-start";
import { analyzeMarket, type Candle } from "./eliz";

const INTERVALS = new Set(["15m", "1h", "4h", "1d"]);

function normSymbol(raw: string) {
  let s = raw.trim().toUpperCase().replace("/", "").replace("-", "");
  if (!s) s = "BTCUSDT";
  if (!/^[A-Z0-9]{4,20}$/.test(s)) throw new Error("Simbol tidak valid");
  if (!s.endsWith("USDT")) s += "USDT";
  return s;
}

function fromBinance(rows: unknown): Candle[] {
  if (!Array.isArray(rows)) return [];
  return rows.map((k) => {
    const r = k as (string | number)[];
    return {
      time: Number(r[0]),
      open: Number(r[1]),
      high: Number(r[2]),
      low: Number(r[3]),
      close: Number(r[4]),
      volume: Number(r[5]),
    };
  });
}

const BYBIT_IV: Record<string, string> = { "15m": "15", "1h": "60", "4h": "240", "1d": "D" };

function fromBybit(body: { result?: { list?: string[][] } }): Candle[] {
  const list = body.result?.list ?? [];
  return list
    .map((r) => ({
      time: Number(r[0]),
      open: Number(r[1]),
      high: Number(r[2]),
      low: Number(r[3]),
      close: Number(r[4]),
      volume: Number(r[5]),
    }))
    .reverse();
}

async function pull(url: string) {
  const res = await fetch(url, { headers: { accept: "application/json" } });
  if (!res.ok) throw new Error(String(res.status));
  return res.json();
}

async function klines(symbol: string, interval: string, limit: number): Promise<{ candles: Candle[]; source: string }> {
  const hosts = ["https://data-api.binance.vision", "https://api.binance.com"];
  for (const host of hosts) {
    try {
      const data = await pull(`${host}/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
      const candles = fromBinance(data);
      if (candles.length > 10) return { candles, source: host.includes("vision") ? "Binance Vision" : "Binance" };
    } catch {
      /* try next */
    }
  }
  const iv = BYBIT_IV[interval] ?? "60";
  const data = await pull(
    `https://api.bybit.com/v5/market/kline?category=spot&symbol=${symbol}&interval=${iv}&limit=${Math.min(limit, 200)}`,
  );
  const candles = fromBybit(data);
  if (candles.length < 10) throw new Error("Data pasar tidak tersedia untuk pair ini");
  return { candles, source: "Bybit" };
}

export const runAnalysis = createServerFn({ method: "GET" })
  .inputValidator((input: { symbol?: string; interval?: string }) => {
    const symbol = normSymbol(input.symbol ?? "BTCUSDT");
    const interval = INTERVALS.has(input.interval ?? "") ? input.interval! : "4h";
    return { symbol, interval };
  })
  .handler(async ({ data }) => {
    const [entry, hourly, daily] = await Promise.all([
      klines(data.symbol, data.interval, 250),
      klines(data.symbol, "1h", 500),
      klines(data.symbol, "1d", 120),
    ]);
    return analyzeMarket({
      symbol: data.symbol,
      source: entry.source,
      entry: entry.candles,
      hourly: hourly.candles,
      daily: daily.candles,
    });
  });
