import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { runAnalysis } from "@/lib/analyze";
import type { Analysis, Candle, Zone } from "@/lib/eliz";

export const Route = createFileRoute("/")({ component: Home });

const PAIRS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT", "ADAUSDT", "DOGEUSDT", "AVAXUSDT", "LINKUSDT", "TAOUSDT"];

function fmt(n: number | null | undefined) {
  if (n == null || Number.isNaN(n)) return "—";
  if (n >= 1000) return n.toLocaleString("en-US", { maximumFractionDigits: 2 });
  if (n >= 1) return n.toLocaleString("en-US", { maximumFractionDigits: 4 });
  return n.toPrecision(4);
}

function Chart({ candles, boxes, high, low }: { candles: Candle[]; boxes: Zone[]; high?: number; low?: number }) {
  const d = useMemo(() => {
    const w = 760;
    const h = 220;
    const data = candles.slice(-80);
    if (data.length < 2) return null;
    let min = Infinity;
    let max = -Infinity;
    for (const c of data) {
      min = Math.min(min, c.low);
      max = Math.max(max, c.high);
    }
    if (high != null) max = Math.max(max, high);
    if (low != null) min = Math.min(min, low);
    const pad = (max - min) * 0.08 || 1;
    min -= pad;
    max += pad;
    const y = (p: number) => h - ((p - min) / (max - min)) * (h - 16) - 8;
    const step = w / data.length;
    const bars = data.map((c, i) => {
      const x = i * step + step * 0.18;
      const bw = Math.max(1.5, step * 0.64);
      const up = c.close >= c.open;
      return { x, bw, up, yH: y(c.high), yL: y(c.low), yO: y(c.open), yC: y(c.close) };
    });
    return { w, h, y, bars, min, max };
  }, [candles, high, low]);
  if (!d) return null;
  return (
    <svg viewBox={`0 0 ${d.w} ${d.h}`} className="h-56 w-full" role="img" aria-label="Chart harga">
      <rect width={d.w} height={d.h} fill="var(--color-raised)" rx="8" />
      {boxes.map((b) => (
        <rect
          key={b.label + b.top}
          x="0"
          y={d.y(b.top)}
          width={d.w}
          height={Math.max(1, d.y(b.bottom) - d.y(b.top))}
          fill={b.kind === "supply" ? "rgba(239,91,91,0.14)" : b.kind === "demand" ? "rgba(47,191,113,0.14)" : "rgba(224,160,74,0.12)"}
        />
      ))}
      {high != null && <line x1="0" x2={d.w} y1={d.y(high)} y2={d.y(high)} stroke="var(--color-amber)" strokeDasharray="5 4" />}
      {low != null && <line x1="0" x2={d.w} y1={d.y(low)} y2={d.y(low)} stroke="var(--color-amber)" strokeDasharray="5 4" />}
      {d.bars.map((b, i) => (
        <g key={i}>
          <line x1={b.x + b.bw / 2} x2={b.x + b.bw / 2} y1={b.yH} y2={b.yL} stroke={b.up ? "var(--color-long)" : "var(--color-short)"} />
          <rect x={b.x} y={Math.min(b.yO, b.yC)} width={b.bw} height={Math.max(1, Math.abs(b.yC - b.yO))} fill={b.up ? "var(--color-long)" : "var(--color-short)"} />
        </g>
      ))}
    </svg>
  );
}

function Home() {
  const [symbol, setSymbol] = useState("BTCUSDT");
  const [custom, setCustom] = useState("");
  const [interval, setInterval] = useState("4h");
  const [equity, setEquity] = useState("10000");
  const [showRules, setShowRules] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [data, setData] = useState<Analysis | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem("eliz-equity");
    if (saved) setEquity(saved);
  }, []);

  async function load(sym = symbol, iv = interval) {
    setLoading(true);
    setError("");
    try {
      const result = await runAnalysis({ data: { symbol: custom.trim() || sym, interval: iv } });
      setData(result);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Gagal mengambil data pasar");
      setData(null);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load("BTCUSDT", "4h");
    // first paint only
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const eq = Number(equity.replace(",", ".")) || 0;
  const riskUsd = eq * 0.0075;

  return (
    <main className="mx-auto min-h-screen max-w-3xl px-4 py-5">
      <header className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="font-mono text-xs tracking-widest text-amber uppercase">Price action desk</p>
          <h1 className="text-2xl font-semibold tracking-tight">EliZ Desk</h1>
          <p className="text-sm text-muted">Monday Range, sweep, deviation, reclaim. Data lewat server, bukan browser.</p>
        </div>
        <button type="button" className="rounded-lg border border-line px-3 py-2 text-sm text-muted" onClick={() => setShowRules((v) => !v)}>
          {showRules ? "Tutup aturan" : "Aturan"}
        </button>
      </header>

      <p className="mb-4 rounded-lg border border-line bg-surface px-3 py-2 text-sm text-muted">
        Bukan saran keuangan. Trading crypto bisa menghabiskan modal. Paper-trade dulu. Metodologi dari catatan publik @eliz883.
      </p>

      {showRules && (
        <section className="mb-4 rounded-xl border border-line bg-surface p-4 text-sm">
          <ol className="list-decimal space-y-2 pl-5 text-muted">
            <li>Strategi hanya membawa masuk. Disiplin yang menghasilkan uang. Risk management yang menahan kamu di pasar.</li>
            <li>Monday Range = high dan low hari Senin (UTC). Di dalam tengah range, jangan memaksa trade.</li>
            <li>Trigger: liquidity sweep di luar level, deviation (false break), lalu reclaim.</li>
            <li>Tiga box di timeframe tinggi: supply, tengah, demand. Level saja bukan sinyal — reaksi yang penting.</li>
            <li>Risk kecil, invalidation jelas. Maksimal 4 ide, tahan paling lama 7 hari.</li>
          </ol>
        </section>
      )}

      <section className="mb-4 flex flex-wrap items-end gap-2 rounded-xl border border-line bg-surface p-3">
        <label className="flex min-w-32 flex-col gap-1 text-xs text-muted">
          Pair
          <select className="rounded-lg border border-line bg-raised px-3 py-2.5 text-sm text-fg" value={symbol} onChange={(e) => { setSymbol(e.target.value); setCustom(""); }}>
            {PAIRS.map((p) => <option key={p} value={p}>{p.replace("USDT", "/USDT")}</option>)}
          </select>
        </label>
        <label className="flex min-w-28 flex-col gap-1 text-xs text-muted">
          Entry TF
          <select className="rounded-lg border border-line bg-raised px-3 py-2.5 text-sm text-fg" value={interval} onChange={(e) => setInterval(e.target.value)}>
            <option value="15m">15m</option>
            <option value="1h">1H</option>
            <option value="4h">4H</option>
            <option value="1d">1D</option>
          </select>
        </label>
        <label className="flex min-w-36 flex-1 flex-col gap-1 text-xs text-muted">
          Pair lain
          <input className="rounded-lg border border-line bg-raised px-3 py-2.5 text-sm text-fg" placeholder="PEPEUSDT" value={custom} onChange={(e) => setCustom(e.target.value)} />
        </label>
        <label className="flex min-w-28 flex-col gap-1 text-xs text-muted">
          Ekuitas USDT
          <input
            className="rounded-lg border border-line bg-raised px-3 py-2.5 text-sm text-fg"
            inputMode="decimal"
            value={equity}
            onChange={(e) => {
              setEquity(e.target.value);
              localStorage.setItem("eliz-equity", e.target.value);
            }}
          />
        </label>
        <button type="button" className="min-h-11 rounded-lg bg-long px-4 py-2.5 text-sm font-semibold text-ink disabled:opacity-60" disabled={loading} onClick={() => void load()}>
          {loading ? "Membaca pasar…" : "Analisis"}
        </button>
      </section>

      {error && <p className="mb-4 rounded-lg border border-short/40 bg-surface px-3 py-2 text-sm text-short">{error}</p>}

      {data && (
        <div className="space-y-3">
          <section className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-surface p-4">
            <div>
              <p className="font-mono text-xs text-muted">{data.symbol} · {data.source}</p>
              <p className="font-mono text-3xl font-medium">{fmt(data.price)}</p>
              <p className="text-xs text-muted">Risk 0,75% ≈ {fmt(riskUsd)} USDT</p>
            </div>
            <p className={`max-w-xs text-right text-lg font-semibold ${data.recClass === "long" ? "text-long" : data.recClass === "short" ? "text-short" : "text-amber"}`}>
              {data.recommendation}
            </p>
          </section>

          <section className="grid gap-3 sm:grid-cols-2">
            <article className="rounded-xl border border-line bg-surface p-4">
              <h2 className="mb-1 text-xs tracking-wide text-muted uppercase">vs Monday Range</h2>
              <p>{data.posRange}</p>
            </article>
            <article className="rounded-xl border border-line bg-surface p-4">
              <h2 className="mb-1 text-xs tracking-wide text-muted uppercase">vs boxes</h2>
              <p>{data.posBoxes}</p>
            </article>
          </section>

          <section className="rounded-xl border border-line bg-surface p-4">
            <h2 className="mb-3 text-xs tracking-wide text-muted uppercase">Monday Range</h2>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {[
                ["High", data.mondayRange?.high],
                ["Low", data.mondayRange?.low],
                ["Mid", data.mondayRange?.mid],
                ["Size", data.mondayRange ? `${data.mondayRange.sizePct.toFixed(2)}%` : null],
              ].map(([k, v]) => (
                <div key={String(k)} className="rounded-lg bg-raised px-3 py-2 text-center">
                  <p className="text-xs text-muted">{k}</p>
                  <p className="font-mono text-sm">{typeof v === "number" ? fmt(v) : v ?? "—"}</p>
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-xl border border-line bg-surface p-4">
            <h2 className="mb-3 text-xs tracking-wide text-muted uppercase">Boxes</h2>
            {data.boxes.length === 0 && <p className="text-sm text-muted">Belum cukup swing untuk tiga box.</p>}
            <ul className="space-y-2">
              {data.boxes.map((b) => (
                <li key={b.label + b.top} className="flex items-center justify-between rounded-lg bg-raised px-3 py-2">
                  <span className={b.kind === "supply" ? "text-short" : b.kind === "demand" ? "text-long" : "text-amber"}>{b.label}</span>
                  <span className="font-mono text-sm text-muted">{fmt(b.bottom)} – {fmt(b.top)}</span>
                </li>
              ))}
            </ul>
          </section>

          <section className="rounded-xl border border-line bg-surface p-4">
            <h2 className="mb-3 text-xs tracking-wide text-muted uppercase">Setup</h2>
            {data.setups.length === 0 && <p className="text-sm text-muted">Tidak ada sweep + reclaim. Tunggu trigger.</p>}
            <ul className="space-y-2">
              {data.setups.map((s, i) => (
                <li key={i} className="rounded-lg border border-line p-3">
                  <div className="mb-1 flex items-center justify-between">
                    <span className={s.direction === "long" ? "font-semibold text-long" : "font-semibold text-short"}>{s.direction.toUpperCase()}</span>
                    <span className="font-mono text-xs text-muted">skor {s.score}</span>
                  </div>
                  <p className="text-sm">{s.reason}</p>
                  <p className="mt-1 font-mono text-xs text-muted">
                    Entry {fmt(s.entryLow)}–{fmt(s.entryHigh)} · SL {fmt(s.invalidation)}
                    {s.target != null ? ` · target ${fmt(s.target)}` : ""} · jarak stop {s.riskPct.toFixed(2)}%
                  </p>
                </li>
              ))}
            </ul>
          </section>

          <section className="rounded-xl border border-line bg-surface p-4">
            <h2 className="mb-2 text-xs tracking-wide text-muted uppercase">Chart entry</h2>
            <Chart candles={data.candles} boxes={data.boxes} high={data.mondayRange?.high} low={data.mondayRange?.low} />
            <p className="mt-2 text-xs text-muted">Garis oranye = Monday High/Low. Merah = supply. Hijau = demand.</p>
          </section>

          <section className="rounded-xl border border-line bg-surface p-4">
            <h2 className="mb-2 text-xs tracking-wide text-muted uppercase">Catatan</h2>
            <ul className="list-disc space-y-1 pl-5 text-sm text-muted">
              {data.notes.map((n) => <li key={n}>{n}</li>)}
            </ul>
          </section>
        </div>
      )}
    </main>
  );
}
