const $ = (id) => document.getElementById(id);

function fmt(n) {
  if (n == null || Number.isNaN(n)) return "—";
  if (n >= 1000) return n.toLocaleString("en-US", { maximumFractionDigits: 2 });
  if (n >= 1) return n.toLocaleString("en-US", { maximumFractionDigits: 4 });
  return Number(n).toPrecision(4);
}

function chartSvg(candles, boxes, high, low) {
  const data = (candles || []).slice(-80);
  if (data.length < 2) return "";
  const w = 760, h = 220;
  let min = Infinity, max = -Infinity;
  for (const c of data) { min = Math.min(min, c.low); max = Math.max(max, c.high); }
  if (high != null) max = Math.max(max, high);
  if (low != null) min = Math.min(min, low);
  const pad = (max - min) * 0.08 || 1;
  min -= pad; max += pad;
  const y = (p) => h - ((p - min) / (max - min)) * (h - 16) - 8;
  const step = w / data.length;
  const zones = (boxes || []).map((b) => {
    const fill = b.kind === "supply" ? "rgba(239,91,91,0.14)" : b.kind === "demand" ? "rgba(47,191,113,0.14)" : "rgba(224,160,74,0.12)";
    return `<rect x="0" y="${y(b.top)}" width="${w}" height="${Math.max(1, y(b.bottom) - y(b.top))}" fill="${fill}"/>`;
  }).join("");
  const lines = [
    high != null ? `<line x1="0" x2="${w}" y1="${y(high)}" y2="${y(high)}" stroke="#e0a04a" stroke-dasharray="5 4"/>` : "",
    low != null ? `<line x1="0" x2="${w}" y1="${y(low)}" y2="${y(low)}" stroke="#e0a04a" stroke-dasharray="5 4"/>` : "",
  ].join("");
  const bars = data.map((c, i) => {
    const x = i * step + step * 0.18;
    const bw = Math.max(1.5, step * 0.64);
    const up = c.close >= c.open;
    const col = up ? "#2fbf71" : "#ef5b5b";
    const yo = y(c.open), yc = y(c.close);
    return `<line x1="${x + bw / 2}" x2="${x + bw / 2}" y1="${y(c.high)}" y2="${y(c.low)}" stroke="${col}"/><rect x="${x}" y="${Math.min(yo, yc)}" width="${bw}" height="${Math.max(1, Math.abs(yc - yo))}" fill="${col}"/>`;
  }).join("");
  return `<svg class="chart" viewBox="0 0 ${w} ${h}" role="img" aria-label="Chart harga">${zones}${lines}${bars}</svg>`;
}

function render(data) {
  const eq = Number(String($("equity").value).replace(",", ".")) || 0;
  const risk = eq * 0.0075;
  const mr = data.mondayRange;
  $("out").classList.remove("hidden");
  $("out").innerHTML = `
    <section class="card hero">
      <div>
        <p class="meta">${data.symbol} · ${data.source}</p>
        <p class="price">${fmt(data.price)}</p>
        <p class="meta">Risk 0,75% ≈ ${fmt(risk)} USDT</p>
      </div>
      <p class="rec ${data.recClass || "none"}">${data.recommendation}</p>
    </section>
    <section class="grid">
      <article class="card"><h2>vs Monday Range</h2><p>${data.posRange}</p></article>
      <article class="card"><h2>vs boxes</h2><p>${data.posBoxes}</p></article>
    </section>
    <section class="card block">
      <h2>Monday Range</h2>
      <div class="stats">
        <div class="stat"><span>High</span><b>${fmt(mr && mr.high)}</b></div>
        <div class="stat"><span>Low</span><b>${fmt(mr && mr.low)}</b></div>
        <div class="stat"><span>Mid</span><b>${fmt(mr && mr.mid)}</b></div>
        <div class="stat"><span>Size</span><b>${mr ? mr.sizePct.toFixed(2) + "%" : "—"}</b></div>
      </div>
    </section>
    <section class="card block">
      <h2>Boxes</h2>
      ${(data.boxes || []).length ? data.boxes.map((b) => `<div class="row"><span class="${b.kind}">${b.label}</span><span class="mono">${fmt(b.bottom)} – ${fmt(b.top)}</span></div>`).join("") : `<p class="sub">Belum cukup swing untuk tiga box.</p>`}
    </section>
    <section class="card block">
      <h2>Setup</h2>
      ${(data.setups || []).length ? data.setups.map((s) => `<div class="setup"><div class="head"><span class="${s.direction}tag">${s.direction.toUpperCase()}</span><span class="mono">skor ${s.score}</span></div><p>${s.reason}</p><p class="mono">Entry ${fmt(s.entryLow)}–${fmt(s.entryHigh)} · SL ${fmt(s.invalidation)}${s.target != null ? " · target " + fmt(s.target) : ""} · jarak stop ${s.riskPct.toFixed(2)}%</p></div>`).join("") : `<p class="sub">Tidak ada sweep + reclaim. Tunggu trigger.</p>`}
    </section>
    <section class="card block">
      <h2>Chart entry</h2>
      ${chartSvg(data.candles, data.boxes, mr && mr.high, mr && mr.low)}
      <p class="sub">Garis oranye = Monday High/Low. Merah = supply. Hijau = demand.</p>
    </section>
    <section class="card">
      <h2>Catatan</h2>
      <ul class="notes">${(data.notes || []).map((n) => `<li>${n}</li>`).join("")}</ul>
    </section>`;
}

async function load() {
  const symbol = $("custom").value.trim() || $("symbol").value;
  const interval = $("interval").value;
  const btn = $("go");
  btn.disabled = true;
  $("status").classList.remove("hidden");
  $("status").textContent = "Membaca pasar…";
  try {
    const res = await fetch(`/api/analyze?symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(interval)}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Analisis gagal");
    $("status").classList.add("hidden");
    render(data);
  } catch (e) {
    $("status").textContent = e.message || "Gagal mengambil data";
  } finally {
    btn.disabled = false;
  }
}

$("rulesBtn").addEventListener("click", () => $("rules").classList.toggle("hidden"));
$("form").addEventListener("submit", (e) => { e.preventDefault(); load(); });
const saved = localStorage.getItem("eliz-equity");
if (saved) $("equity").value = saved;
$("equity").addEventListener("change", () => localStorage.setItem("eliz-equity", $("equity").value));
load();
