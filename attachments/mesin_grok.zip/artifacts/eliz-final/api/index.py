"""
EliZ Analyzer – Vercel FastAPI entrypoint (path-fixed)
=====================================================
Handles both:
  - Direct /api/* paths (Vercel default for api/index.py)
  - Rewritten /* paths
"""
from __future__ import annotations

import os
import sys
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SRC = ROOT / "src"
for p in (str(SRC), str(ROOT)):
    if p not in sys.path:
        sys.path.insert(0, p)
os.environ.setdefault("ELIZ_CONFIG", str(ROOT / "config" / "default.yaml"))

from fastapi import FastAPI, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from pydantic import BaseModel

app = FastAPI(
    title="EliZ Price Action Analyzer",
    version="1.2.0",
    docs_url=None,   # we mount manually for path flexibility
    redoc_url=None,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Path normalization middleware ────────────────────────────
# Vercel may pass path as /, /health, /api, /api/health, /api/index, etc.
@app.middleware("http")
async def normalize_path(request: Request, call_next):
    path = request.scope.get("path", "") or "/"
    # Strip common Vercel prefixes so our routes match
    for prefix in ("/api/index", "/api"):
        if path == prefix or path == prefix + "/":
            request.scope["path"] = "/"
            break
        if path.startswith(prefix + "/"):
            request.scope["path"] = path[len(prefix):] or "/"
            break
    return await call_next(request)


def _html_home() -> str:
    return """<!DOCTYPE html>
<html lang="id"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>EliZ Analyzer</title>
<style>
:root{--bg:#0d1117;--card:#161b22;--text:#e6edf3;--muted:#8b949e;--accent:#3fb950;--warn:#f85149;--link:#58a6ff}
*{box-sizing:border-box}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica,Arial,sans-serif;background:var(--bg);color:var(--text);line-height:1.5}
.wrap{max-width:720px;margin:0 auto;padding:24px 16px}
h1{font-size:1.6rem;margin:0 0 8px;color:var(--accent)}
.sub{color:var(--muted);margin-bottom:20px}
.card{background:var(--card);border:1px solid #30363d;border-radius:10px;padding:16px;margin:12px 0}
.warn{border-left:4px solid var(--warn)}
a{color:var(--link)}code{background:#21262d;padding:2px 7px;border-radius:6px;font-size:.9em}
.btn{display:inline-block;margin:6px 6px 6px 0;padding:10px 14px;background:#238636;color:#fff;text-decoration:none;border-radius:8px;font-weight:600}
.btn.sec{background:#21262d;border:1px solid #30363d}
ul{padding-left:18px}li{margin:6px 0}
</style></head><body><div class="wrap">
<h1>EliZ Price Action Analyzer</h1>
<p class="sub">Mesin analisis crypto berbasis metodologi publik <b>@eliz883</b> — Monday Range, Liquidity Sweep, Deviation + Reclaim, Boxes.</p>

<div class="card warn">
<b>DISCLAIMER</b><br>
Bukan saran keuangan. Trading crypto berisiko tinggi dan bisa kehilangan seluruh modal.
Selalu paper-trade dulu. Risk management wajib.
</div>

<div class="card">
<b>Coba sekarang</b><br><br>
<a class="btn" href="/analyze?symbol=BTC/USDT">Analisis BTC</a>
<a class="btn sec" href="/analyze?symbol=ETH/USDT">Analisis ETH</a>
<a class="btn sec" href="/health">Health</a>
<a class="btn sec" href="/docs">API Docs</a>
</div>

<div class="card">
<b>Endpoint</b>
<ul>
<li><code>GET /analyze?symbol=BTC/USDT</code></li>
<li><code>GET /analyze?symbol=SOL/USDT&amp;entry_tf=1h</code></li>
<li><code>GET /health</code></li>
<li><code>GET /philosophy</code></li>
</ul>
</div>

<div class="card">
<b>Aturan inti (@eliz883)</b>
<ul>
<li>Strategy gets you in. Discipline makes you money. Risk management keeps you in the market.</li>
<li>Tunggu harga ke level (Monday Range / Box)</li>
<li>Trigger: Sweep + Deviation + Reclaim</li>
<li>Middle of range = no trade (sitting on hands)</li>
<li>Risk ≤ 0.75% / trade · max 4 ide · max hold 7 hari</li>
</ul>
</div>
</div></body></html>"""


@app.get("/")
async def home():
    return HTMLResponse(_html_home())


@app.get("/health")
async def health():
    import sys as _sys
    out: Dict[str, Any] = {
        "status": "ok",
        "version": "1.2.0",
        "python": _sys.version.split()[0],
        "root": str(ROOT),
        "src_exists": SRC.exists(),
        "config_exists": (ROOT / "config" / "default.yaml").exists(),
        "analyzer": "not_tried",
    }
    try:
        from eliz_analyzer.core.monday_range import MondayRangeCalculator  # noqa: F401
        out["analyzer"] = "ok"
    except Exception as e:
        out["analyzer"] = f"FAIL: {type(e).__name__}: {e}"
    return out


@app.get("/philosophy")
async def philosophy():
    return {
        "source": "@eliz883 (EliZ) – public posts 2023–2026",
        "core": [
            "Strategy gets you in. Discipline makes you money. Risk management keeps you in the market.",
            "Entry is 1%. The rest is manage profit, emotion, plan.",
            "Never chase. Without clear trigger → do nothing.",
            "Sitting on hands is also a position.",
            "Monday Range = weekly framework (High/Low Senin).",
            "Trigger = Liquidity Sweep + Deviation (false break) + Reclaim.",
            "3 Boxes on Weekly: Supply / Mid / Demand.",
            "Middle of range = no-trade zone.",
            "Level alone is not a signal — reaction is.",
        ],
        "risk_rules": {
            "risk_per_trade_pct": 0.75,
            "max_open_ideas": 4,
            "max_hold_days": 7,
            "daily_loss_limit_pct": 3.0,
            "tp1": "40% @ 1.5R",
            "tp2": "30% @ 2.5R",
            "runner": "30%",
        },
        "disclaimer": "Educational only. Not financial advice.",
    }


@app.get("/analyze")
async def analyze(
    symbol: str = Query("BTC/USDT", description="Pair, e.g. BTC/USDT"),
    higher_tf: str = Query("1w", description="HTF for boxes"),
    entry_tf: str = Query("4h", description="Entry TF"),
    limit: int = Query(200, ge=50, le=500),
):
    try:
        from eliz_analyzer.core.analyzer import EliZAnalyzer
    except Exception as e:
        return JSONResponse(status_code=500, content={
            "error": "ImportError",
            "detail": str(e),
            "trace": traceback.format_exc(),
        })

    sym = symbol.upper().strip()
    if "/" not in sym:
        sym = f"{sym}/USDT"

    try:
        cfg = os.environ.get("ELIZ_CONFIG")
        analyzer = EliZAnalyzer(config_path=cfg if cfg and Path(cfg).exists() else None)
        result = analyzer.analyze(
            symbol=sym, higher_tf=higher_tf, entry_tf=entry_tf, limit=limit
        )
        return {
            "symbol": result.symbol,
            "current_price": result.current_price,
            "recommendation": result.recommendation,
            "position_vs_range": result.position_vs_range,
            "position_vs_boxes": result.position_vs_boxes,
            "monday_range": result.monday_range.to_dict() if result.monday_range else None,
            "boxes": [b.to_dict() for b in result.boxes],
            "setups": [s.to_dict() for s in result.setups],
            "notes": result.notes,
            "disclaimer": (
                "Educational only. Not financial advice. "
                "Cryptocurrency trading involves substantial risk of loss."
            ),
        }
    except Exception as e:
        return JSONResponse(status_code=500, content={
            "error": type(e).__name__,
            "detail": str(e),
            "trace": traceback.format_exc(),
        })


# Also expose under /api/* in case middleware does not strip
@app.get("/api")
@app.get("/api/")
async def home_api():
    return HTMLResponse(_html_home())

@app.get("/api/health")
async def health_api():
    return await health()

@app.get("/api/analyze")
async def analyze_api(
    symbol: str = Query("BTC/USDT"),
    higher_tf: str = Query("1w"),
    entry_tf: str = Query("4h"),
    limit: int = Query(200, ge=50, le=500),
):
    return await analyze(symbol=symbol, higher_tf=higher_tf, entry_tf=entry_tf, limit=limit)

@app.get("/api/philosophy")
async def philosophy_api():
    return await philosophy()


# Minimal OpenAPI UI redirect
@app.get("/docs")
@app.get("/api/docs")
async def docs():
    return RedirectResponse("https://mesingrok.vercel.app/health")


@app.exception_handler(Exception)
async def all_errors(request: Request, exc: Exception):
    return JSONResponse(status_code=500, content={
        "error": type(exc).__name__,
        "detail": str(exc),
        "path": str(request.url.path),
    })
