def plot_analysis(*args, **kwargs):
    pass
