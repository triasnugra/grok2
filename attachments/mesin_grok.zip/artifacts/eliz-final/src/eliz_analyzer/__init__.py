__version__ = "1.2.0"
__all__ = ["EliZAnalyzer"]

def __getattr__(name):
    if name == "EliZAnalyzer":
        from .core.analyzer import EliZAnalyzer
        return EliZAnalyzer
    raise AttributeError(name)
