"""
Vercel Drop entrypoint – ultra defensive.
Must not crash on import. Heavy work only inside handlers.
"""
from __future__ import annotations

import os
import sys
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

# Resolve project root (works for Vercel Drop + Git)
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SRC = ROOT / "src"

for p in (str(SRC), str(ROOT)):
    if p not in sys.path:
        sys.path.insert(0, p)

os.environ.setdefault("ELIZ_CONFIG", str(ROOT / "config" / "default.yaml"))

# ── FastAPI must load or we have nothing ─────────────────────
try:
    from fastapi import FastAPI, Query
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import HTMLResponse, JSONResponse
    from pydantic import BaseModel
except Exception as e:
    # Last resort: if even FastAPI fails, raise clearly
    raise RuntimeError(f"FastAPI import failed: {e}") from e

app = FastAPI(title="EliZ Analyzer", version="1.1.2", docs_url="/docs")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


class HealthOut(BaseModel):
    status: str = "ok"
    version: str = "1.1.2"
    python: str = ""
    root: str = ""
    src_exists: bool = False
    config_exists: bool = False
    analyzer_import: str = "not_tried"


@app.get("/", response_class=HTMLResponse)
async def home():
    return """<!DOCTYPE html><html><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>EliZ Analyzer</title>
<style>
body{font-family:system-ui;max-width:640px;margin:40px auto;padding:0 16px;background:#111;color:#eee}
h1{color:#26a69a}.w{background:#3e2723;border-left:4px solid #ef5350;padding:12px;margin:16px 0}
a{color:#42a5f5}code{background:#222;padding:2px 6px;border-radius:4px}
</style></head><body>
<h1>EliZ Price Action Analyzer</h1>
<p>Educational tool based on @eliz883 public methodology.</p>
<div class=w><b>DISCLAIMER</b><br>Not financial advice. Trading can lose all capital.</div>
<ul>
<li><a href="/health">/health</a></li>
<li><a href="/docs">/docs</a></li>
<li><code>/analyze?symbol=BTC/USDT</code></li>
<li><a href="/philosophy">/philosophy</a></li>
</ul>
</body></html>"""


@app.get("/health")
async def health():
    import sys as _sys
    info = {
        "status": "ok",
        "version": "1.1.2",
        "python": _sys.version.split()[0],
        "root": str(ROOT),
        "src_exists": SRC.exists(),
        "config_exists": (ROOT / "config" / "default.yaml").exists(),
        "analyzer_import": "not_tried",
    }
    # Try light import test (don't run analysis)
    try:
        from eliz_analyzer.core.monday_range import MondayRangeCalculator  # noqa: F401
        info["analyzer_import"] = "ok"
    except Exception as e:
        info["analyzer_import"] = f"FAIL: {type(e).__name__}: {e}"
    return info


@app.get("/philosophy")
async def philosophy():
    return {
        "core": [
            "Strategy gets you in. Discipline makes you money. Risk management keeps you in the market.",
            "Never chase. No trigger = no trade.",
            "Sitting on hands is also a position.",
            "Sweep + Deviation + Reclaim = high probability trigger.",
        ],
        "risk": {"risk_per_trade_pct": 0.75, "max_open": 4, "max_hold_days": 7},
        "disclaimer": "Educational only. Not financial advice.",
    }


@app.get("/analyze")
async def analyze(
    symbol: str = Query("BTC/USDT"),
    higher_tf: str = Query("1w"),
    entry_tf: str = Query("4h"),
    limit: int = Query(200, ge=50, le=500),
):
    try:
        from eliz_analyzer.core.analyzer import EliZAnalyzer
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "error": "ImportError",
                "detail": str(e),
                "trace": traceback.format_exc(),
                "hint": "Check /health → analyzer_import field",
            },
        )

    sym = symbol.upper().strip()
    if "/" not in sym:
        sym = f"{sym}/USDT"

    try:
        cfg = os.environ.get("ELIZ_CONFIG")
        analyzer = EliZAnalyzer(config_path=cfg if cfg and Path(cfg).exists() else None)
        result = analyzer.analyze(symbol=sym, higher_tf=higher_tf, entry_tf=entry_tf, limit=limit)
        return {
            "symbol": result.symbol,
            "current_price": result.current_price,
            "recommendation": result.recommendation,
            "position_vs_range": result.position_vs_range,
            "position_vs_boxes": result.position_vs_boxes,
            "monday_range": result.monday_range.to_dict() if result.monday_range else None,
            "boxes": [b.to_dict() for b in result.boxes],
            "setups": [s.to_dict() for s in result.setups],
            "notes": result.notes,
            "disclaimer": "Educational only. Not financial advice. Trading involves substantial risk of loss.",
        }
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "error": type(e).__name__,
                "detail": str(e),
                "trace": traceback.format_exc(),
            },
        )


@app.exception_handler(Exception)
async def on_error(request, exc):
    return JSONResponse(
        status_code=500,
        content={"error": type(exc).__name__, "detail": str(exc)},
    )
