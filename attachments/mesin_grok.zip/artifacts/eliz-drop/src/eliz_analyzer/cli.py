"""
Command Line Interface for EliZ Real-Money Ready Analyzer
=========================================================
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional

import click
from eliz_analyzer.console_util import console, Console, Table, Panel


from .core.analyzer import EliZAnalyzer
from .visualization.charts import plot_analysis
from .signals.generator import SignalGenerator
from .paper.journal import PaperJournal

console = Console()


@click.group()
@click.version_option(version="1.1.0")
def main():
    """
    EliZ (@eliz883) Price Action Analysis Engine – Real-Money Ready Edition

    Pure Price Action • Monday Range • Liquidity Sweep • Deviation + Reclaim
    + Strict Risk Management + Paper Journal
    """
    pass


# ─────────────────────────────────────────────────────────────
# ANALYSIS
# ─────────────────────────────────────────────────────────────

@main.command()
@click.argument("symbol", default="BTC/USDT")
@click.option("--higher-tf", default="1w")
@click.option("--entry-tf", default="4h")
@click.option("--monday-tf", default="1h")
@click.option("--limit", default=500)
@click.option("--chart", is_flag=True)
@click.option("--save-chart", type=click.Path())
@click.option("--json-out", type=click.Path())
@click.option("--config", type=click.Path(exists=True))
def analyze(symbol, higher_tf, entry_tf, monday_tf, limit, chart, save_chart, json_out, config):
    """Run full EliZ analysis on one symbol (no risk sizing)."""
    analyzer = EliZAnalyzer(config_path=config)
    result = analyzer.analyze(
        symbol=symbol,
        higher_tf=higher_tf,
        entry_tf=entry_tf,
        monday_tf=monday_tf,
        limit=limit,
    )

    if chart or save_chart:
        data = analyzer.fetcher.fetch_ohlcv(symbol, timeframe=entry_tf, limit=limit)
        path = save_chart or f"./output/charts/{symbol.replace('/', '_')}_{entry_tf}.png"
        plot_analysis(
            df=data,
            symbol=symbol,
            monday_range=result.monday_range,
            boxes=result.boxes,
            setups=result.setups,
            save_path=path,
        )

    if json_out:
        Path(json_out).parent.mkdir(parents=True, exist_ok=True)
        with open(json_out, "w", encoding="utf-8") as f:
            json.dump(result.to_dict(), f, indent=2, ensure_ascii=False)
        console.print(f"[green]JSON saved → {json_out}[/green]")


@main.command()
@click.option("-s", "--symbols", multiple=True, default=["BTC/USDT", "ETH/USDT", "SOL/USDT"])
@click.option("--higher-tf", default="1w")
@click.option("--entry-tf", default="4h")
@click.option("--config", type=click.Path(exists=True))
def scan(symbols, higher_tf, entry_tf, config):
    """Quick scan of multiple symbols (analysis only)."""
    analyzer = EliZAnalyzer(config_path=config)
    results = analyzer.analyze_multiple(list(symbols), higher_tf=higher_tf, entry_tf=entry_tf)

    console.print("\n[bold magenta]═══ SCAN SUMMARY ═══[/bold magenta]")
    ranked = []
    for r in results:
        best_score = max((s.score for s in r.setups), default=0)
        ranked.append((best_score, r))
    ranked.sort(key=lambda x: x[0], reverse=True)
    for score, r in ranked:
        console.print(f"  {r.symbol:12} | Best score {score:3} | {r.recommendation}")


# ─────────────────────────────────────────────────────────────
# SIGNAL / IDEA GENERATION (with risk)
# ─────────────────────────────────────────────────────────────

@main.command()
@click.argument("symbol", default="BTC/USDT")
@click.option("--config", type=click.Path(exists=True))
def idea(symbol, config):
    """
    Generate a risk-managed trade idea for one symbol.
    Idea is recorded in the paper journal as 'pending'.
    """
    gen = SignalGenerator(config_path=config)
    ideas = gen.generate_for_symbol(symbol)
    if not ideas:
        console.print("[yellow]No valid idea generated (score too low or risk gate).[/yellow]")


@main.command()
@click.option("-s", "--symbols", multiple=True, default=["BTC/USDT", "ETH/USDT", "SOL/USDT"])
@click.option("--config", type=click.Path(exists=True))
def ideas(symbols, config):
    """Scan multiple symbols and generate risk-managed ideas."""
    gen = SignalGenerator(config_path=config)
    all_ideas = gen.generate_scan(list(symbols))
    console.print(f"\n[bold]Total ideas created: {len(all_ideas)}[/bold]")


# ─────────────────────────────────────────────────────────────
# PAPER JOURNAL
# ─────────────────────────────────────────────────────────────

@main.group()
def paper():
    """Paper trading journal commands."""
    pass


@paper.command("summary")
@click.option("--config", type=click.Path(exists=True))
def paper_summary(config):
    """Show paper journal equity & performance."""
    gen = SignalGenerator(config_path=config)
    gen.journal_summary()


@paper.command("list")
@click.option("--status", default=None, help="Filter: pending / open / closed")
@click.option("--config", type=click.Path(exists=True))
def paper_list(status, config):
    """List all ideas in the journal."""
    gen = SignalGenerator(config_path=config)
    ideas = gen.journal.load_ideas()
    if status:
        ideas = [i for i in ideas if i.status == status]

    table = Table(title="Paper Journal Ideas", header_style="bold")
    table.add_column("ID")
    table.add_column("Symbol")
    table.add_column("Dir")
    table.add_column("Score")
    table.add_column("Status")
    table.add_column("Entry")
    table.add_column("R")
    table.add_column("Created")

    for i in ideas[-30:]:  # last 30
        table.add_row(
            i.id,
            i.symbol,
            i.direction.upper(),
            str(i.score),
            i.status,
            f"{i.entry_price:.4f}" if i.entry_price else "-",
            f"{i.realized_r:.2f}" if i.realized_r is not None else "-",
            i.created_at[:16],
        )
    console.print(table)


@paper.command("open")
@click.argument("idea_id")
@click.argument("entry_price", type=float)
@click.option("--config", type=click.Path(exists=True))
def paper_open(idea_id, entry_price, config):
    """
    Open a pending idea at the given entry price (paper).
    Example: eliz-analyzer paper open a1b2c3d4 67250.5
    """
    gen = SignalGenerator(config_path=config)
    ideas = gen.journal.load_ideas()
    target = None
    for i in ideas:
        if i.id == idea_id and i.status == "pending":
            target = i
            break
    if not target:
        console.print(f"[red]Idea {idea_id} not found or not pending.[/red]")
        return

    from .risk.manager import RiskManager
    risk = RiskManager(gen.cfg)
    equity = gen.journal.get_equity()

    # Use the original invalidation as structure-based stop
    stop_price = target.invalidation
    pos = risk.size_position(
        equity=equity,
        entry_price=entry_price,
        stop_price=stop_price,
        direction=target.direction,
        symbol=target.symbol,
    )

    opened = gen.journal.open_idea(idea_id, pos)
    if opened:
        console.print(f"[green]Paper trade opened: {idea_id} @ {entry_price}[/green]")
        console.print(f"  Stop: {pos.stop_price:.4f} | TP1: {pos.tp1_price:.4f} | TP2: {pos.tp2_price:.4f}")
        console.print(f"  Risk: {pos.risk_amount:.2f} USDT ({pos.risk_pct}%)")
    else:
        console.print("[red]Failed to open.[/red]")


@paper.command("close")
@click.argument("idea_id")
@click.argument("exit_price", type=float)
@click.option("--reason", default="manual")
@click.option("--config", type=click.Path(exists=True))
def paper_close(idea_id, exit_price, reason, config):
    """
    Close an open paper trade.
    Example: eliz-analyzer paper close a1b2c3d4 68100 --reason tp1
    """
    gen = SignalGenerator(config_path=config)
    ideas = gen.journal.load_ideas()
    target = None
    for i in ideas:
        if i.id == idea_id and i.status == "open":
            target = i
            break
    if not target or target.entry_price is None or target.stop_price is None:
        console.print(f"[red]Open idea {idea_id} not found.[/red]")
        return

    # Calculate realized R
    risk_dist = abs(target.entry_price - target.stop_price)
    if target.direction == "long":
        pnl_dist = exit_price - target.entry_price
    else:
        pnl_dist = target.entry_price - exit_price
    realized_r = pnl_dist / risk_dist if risk_dist > 0 else 0.0

    closed = gen.journal.close_idea(idea_id, exit_price, reason, realized_r)
    if closed:
        color = "green" if realized_r > 0 else "red"
        console.print(f"[{color}]Closed {idea_id} @ {exit_price} → {realized_r:.2f}R ({reason})[/{color}]")
    else:
        console.print("[red]Failed to close.[/red]")


# ─────────────────────────────────────────────────────────────
# PHILOSOPHY
# ─────────────────────────────────────────────────────────────

@main.command()
def philosophy():
    """Print the core trading philosophy of @eliz883 + risk rules."""
    text = """
[bold cyan]Core Philosophy of @eliz883 (EliZ) + Real-Money Rules[/bold cyan]

1. [bold]Strategy gets you in. Discipline makes you money.
   Risk management keeps you in the market.[/bold]

2. Entry is only 1% of the game. The other 99% is managing profits,
   controlling emotions, and sticking to the plan.

3. Never chase price. Without a clear trigger → do nothing.
   Sitting on hands is also a position.

4. High-probability triggers only:
   - Liquidity Sweep outside the range
   - Deviation (false break)
   - Reclaim + clear reaction

5. [bold]Risk Rules (this engine)[/bold]
   - Risk ≤ 0.75% of equity per trade
   - Max 4 open ideas
   - Max hold 7 days
   - Stop based on ATR (1.8–3.5×) with hard 1.2–8% caps
   - TP1 40% at 1.5R, TP2 30% at 2.5R, 30% runner
   - Daily loss limit 3% → stop trading for the day

6. Always paper-trade first. Real money only after proven edge
   and emotional control.

[dim]This tool is educational. Not financial advice.
Cryptocurrency trading involves substantial risk of loss.[/dim]
"""
    console.print(text)


if __name__ == "__main__":
    main()