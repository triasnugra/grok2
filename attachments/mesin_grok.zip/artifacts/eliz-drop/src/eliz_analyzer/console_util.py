"""Lightweight console that falls back to print if rich is missing."""
try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    HAS_RICH = True
except ImportError:
    HAS_RICH = False

    class Console:
        def print(self, *args, **kwargs):
            # strip simple rich markup
            text = " ".join(str(a) for a in args)
            for tag in ["bold", "cyan", "green", "red", "yellow", "magenta", "dim", "white"]:
                text = text.replace(f"[{tag}]", "").replace(f"[/{tag}]", "")
                text = text.replace(f"[bold {tag}]", "").replace(f"[/{tag}]", "")
            print(text)

    class Table:
        def __init__(self, *a, **k):
            self.rows = []
            self.title = k.get("title", "")
        def add_column(self, *a, **k): pass
        def add_row(self, *a, **k):
            self.rows.append(a)
        def __str__(self):
            return "\n".join(str(r) for r in self.rows)

    class Panel:
        def __init__(self, renderable, **k):
            self.renderable = renderable
        def __str__(self):
            return str(self.renderable)

console = Console()
