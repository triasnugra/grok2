"""
Signal / Idea Generator
=======================
Combines EliZ pattern detection + Risk Manager + Paper Journal.
Only produces ideas that pass all risk gates.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any

import pandas as pd
from eliz_analyzer.console_util import console, Console, Table, Panel



from ..core.analyzer import EliZAnalyzer, AnalysisResult
from ..core.patterns import Setup
from ..risk.manager import RiskManager, PositionSize
from ..paper.journal import PaperJournal, Idea



@dataclass
class TradeIdea:
    """Final trade idea ready for paper or (carefully) live execution."""
    idea: Idea
    position: PositionSize
    analysis: AnalysisResult
    risk_check_passed: bool
    message: str


class SignalGenerator:
    """
    High-level pipeline:

    1. Run EliZ analysis
    2. Filter by min score
    3. Apply risk gates (max open, daily loss, exposure)
    4. Size the position with ATR stop + R-multiples
    5. Record in paper journal (or return for live review)
    """

    def __init__(self, config: Optional[dict] = None, config_path: Optional[str] = None):
        self.analyzer = EliZAnalyzer(config_path=config_path, config=config)
        self.cfg = self.analyzer.cfg
        self.risk = RiskManager(self.cfg)
        paper_cfg = self.cfg.get("paper", {})
        self.journal = PaperJournal(
            journal_dir=paper_cfg.get("journal_path", "./output/journal"),
            starting_equity=float(paper_cfg.get("starting_equity", 10000.0)),
        )
        self.rules_hash = self.cfg.get("rules_hash", "eliz-unknown")
        self.min_score = self.cfg.get("scoring", {}).get("min_score_for_idea", 72)

    def generate_for_symbol(self, symbol: str, **kwargs) -> List[TradeIdea]:
        result = self.analyzer.analyze(symbol, **kwargs)
        ideas: List[TradeIdea] = []

        # Risk state
        equity = self.journal.get_equity()
        open_count = self.journal.get_open_count()
        total_risk = self.journal.get_total_risk_pct()
        daily_pnl = self.journal.get_daily_pnl_pct()

        risk_state = self.risk.check_can_open(equity, open_count, total_risk, daily_pnl)

        if not risk_state.can_open_new:
            console.print(f"[yellow]Risk gate blocked new ideas for {symbol}: {risk_state.reason}[/yellow]")
            return []

        # Only high quality setups
        good_setups = [s for s in result.setups if s.score >= self.min_score]

        if not good_setups:
            console.print(f"[dim]No setup above score {self.min_score} for {symbol}[/dim]")
            return []

        # Take only the best one per symbol (keep it simple)
        best = good_setups[0]

        # Determine entry price (use mid of entry zone or current price if inside)
        entry_low, entry_high = best.entry_zone
        current = result.current_price
        if entry_low <= current <= entry_high:
            entry_price = current
        else:
            # Use the edge closer to current price
            entry_price = entry_low if best.direction == "long" else entry_high

        # Fetch entry TF data for ATR
        df_entry = self.analyzer.fetcher.fetch_ohlcv(
            symbol,
            timeframe=self.cfg.get("timeframes", {}).get("entry", "4h"),
            limit=100,
        )

        stop_price = self.risk.calculate_stop(
            df_entry,
            entry_price,
            best.direction,
            structure_invalidation=best.invalidation,
        )

        try:
            pos = self.risk.size_position(
                equity=equity,
                entry_price=entry_price,
                stop_price=stop_price,
                direction=best.direction,
                symbol=symbol,
            )
        except ValueError as e:
            console.print(f"[red]Sizing failed: {e}[/red]")
            return []

        # Create journal entry
        idea = self.journal.create_idea(
            symbol=symbol,
            direction=best.direction,
            score=best.score,
            reason=best.reason,
            entry_zone=best.entry_zone,
            invalidation=best.invalidation,
            rules_hash=self.rules_hash,
        )

        trade_idea = TradeIdea(
            idea=idea,
            position=pos,
            analysis=result,
            risk_check_passed=True,
            message="Idea created in paper journal. Review before opening.",
        )
        ideas.append(trade_idea)

        self._print_idea(trade_idea)
        return ideas

    def generate_scan(self, symbols: Optional[List[str]] = None, **kwargs) -> List[TradeIdea]:
        symbols = symbols or self.cfg.get("symbols", ["BTC/USDT"])
        all_ideas: List[TradeIdea] = []

        for sym in symbols:
            try:
                ideas = self.generate_for_symbol(sym, **kwargs)
                all_ideas.extend(ideas)
            except Exception as e:
                console.print(f"[red]Error on {sym}: {e}[/red]")

        return all_ideas

    def open_paper_trade(self, idea_id: str) -> Optional[Idea]:
        """Mark an idea as open (paper)."""
        ideas = self.journal.load_ideas()
        for idea in ideas:
            if idea.id == idea_id and idea.status == "pending":
                # Rebuild PositionSize from stored data is complex;
                # for simplicity we re-size at open time with current equity
                equity = self.journal.get_equity()
                # We need current price – user should call this when ready
                console.print("[yellow]Use the CLI 'paper open' command with current price.[/yellow]")
                return None
        return None

    def journal_summary(self):
        s = self.journal.summary()
        table = Table(title="Paper Journal Summary", header_style="bold cyan")
        table.add_column("Metric")
        table.add_column("Value")
        table.add_row("Equity", f"{s['equity']:.2f} USDT")
        table.add_row("Starting", f"{s['starting_equity']:.2f}")
        table.add_row("Peak", f"{s['peak']:.2f}")
        table.add_row("Open Ideas", str(s["open_ideas"]))
        table.add_row("Closed", str(s["closed_ideas"]))
        table.add_row("Total R", str(s["total_r"]))
        table.add_row("Win Rate", f"{s['win_rate']}%")
        table.add_row("Avg R", str(s["avg_r"]))
        console.print(table)
        return s

    def _print_idea(self, ti: TradeIdea):
        pos = ti.position
        idea = ti.idea
        color = "green" if idea.direction == "long" else "red"

        console.print(Panel(
            f"[bold {color}]{idea.direction.upper()}[/bold {color}]  {idea.symbol}  |  Score {idea.score}\n"
            f"Reason: {idea.reason}\n\n"
            f"Entry ≈ {pos.entry_price:.4f}\n"
            f"Stop   {pos.stop_price:.4f}  ({pos.stop_distance_pct:.2f}%)\n"
            f"TP1    {pos.tp1_price:.4f}  ({pos.r_multiple_tp1}R) – close {self.risk.tp1_size_pct}%\n"
            f"TP2    {pos.tp2_price:.4f}  ({pos.r_multiple_tp2}R) – close {self.risk.tp2_size_pct}%\n"
            f"Risk   {pos.risk_amount:.2f} USDT  ({pos.risk_pct}% of equity)\n"
            f"Size   {pos.position_size:.6f}  (~{pos.position_value:.2f} USDT)\n\n"
            f"Idea ID: {idea.id}  |  Rules: {idea.rules_hash}\n"
            f"[dim]Status: pending – review then open in paper journal[/dim]",
            title="New Trade Idea",
            border_style=color,
        ))