"""
Paper Trading Journal
=====================
Records every idea, entry, partial closes, and final R-multiple.
Designed so you can audit every decision before going live.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import List, Optional, Dict, Any

from ..risk.manager import PositionSize


@dataclass
class Idea:
    id: str
    symbol: str
    direction: str
    score: int
    reason: str
    entry_zone: tuple
    invalidation: float
    created_at: str
    status: str = "pending"          # pending | open | closed | cancelled
    entry_price: Optional[float] = None
    stop_price: Optional[float] = None
    size: Optional[float] = None
    risk_amount: Optional[float] = None
    tp1_price: Optional[float] = None
    tp2_price: Optional[float] = None
    opened_at: Optional[str] = None
    closed_at: Optional[str] = None
    exit_price: Optional[float] = None
    exit_reason: Optional[str] = None
    realized_r: Optional[float] = None
    notes: List[str] = field(default_factory=list)
    rules_hash: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


class PaperJournal:
    """
    Simple file-based journal. Every idea is versioned with rules_hash
    so you can never mix different rule sets.
    """

    def __init__(self, journal_dir: str = "./output/journal", starting_equity: float = 10000.0):
        self.dir = Path(journal_dir)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.equity_file = self.dir / "equity.json"
        self.ideas_file = self.dir / "ideas.jsonl"
        self.starting_equity = starting_equity
        self._ensure_equity()

    def _ensure_equity(self):
        if not self.equity_file.exists():
            self._write_equity({
                "starting": self.starting_equity,
                "current": self.starting_equity,
                "peak": self.starting_equity,
                "daily_pnl": 0.0,
                "last_reset": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
            })

    def _read_equity(self) -> dict:
        with open(self.equity_file, "r") as f:
            return json.load(f)

    def _write_equity(self, data: dict):
        with open(self.equity_file, "w") as f:
            json.dump(data, f, indent=2)

    def get_equity(self) -> float:
        return float(self._read_equity()["current"])

    def get_open_count(self) -> int:
        ideas = self.load_ideas()
        return sum(1 for i in ideas if i.status == "open")

    def get_total_risk_pct(self) -> float:
        # Simplified: each open idea risks risk_per_trade
        # In production you would sum actual remaining risk
        return self.get_open_count() * 0.75   # approximate

    def get_daily_pnl_pct(self) -> float:
        eq = self._read_equity()
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        if eq.get("last_reset") != today:
            # reset daily pnl
            eq["daily_pnl"] = 0.0
            eq["last_reset"] = today
            self._write_equity(eq)
        return float(eq.get("daily_pnl", 0.0))

    def create_idea(
        self,
        symbol: str,
        direction: str,
        score: int,
        reason: str,
        entry_zone: tuple,
        invalidation: float,
        rules_hash: str,
    ) -> Idea:
        idea = Idea(
            id=str(uuid.uuid4())[:8],
            symbol=symbol,
            direction=direction,
            score=score,
            reason=reason,
            entry_zone=entry_zone,
            invalidation=invalidation,
            created_at=datetime.now(timezone.utc).isoformat(),
            rules_hash=rules_hash,
        )
        self._append(idea)
        return idea

    def open_idea(self, idea_id: str, pos: PositionSize) -> Optional[Idea]:
        ideas = self.load_ideas()
        for idea in ideas:
            if idea.id == idea_id and idea.status == "pending":
                idea.status = "open"
                idea.entry_price = pos.entry_price
                idea.stop_price = pos.stop_price
                idea.size = pos.position_size
                idea.risk_amount = pos.risk_amount
                idea.tp1_price = pos.tp1_price
                idea.tp2_price = pos.tp2_price
                idea.opened_at = datetime.now(timezone.utc).isoformat()
                self._rewrite_all(ideas)
                return idea
        return None

    def close_idea(
        self,
        idea_id: str,
        exit_price: float,
        exit_reason: str,
        realized_r: float,
    ) -> Optional[Idea]:
        ideas = self.load_ideas()
        for idea in ideas:
            if idea.id == idea_id and idea.status == "open":
                idea.status = "closed"
                idea.exit_price = exit_price
                idea.exit_reason = exit_reason
                idea.realized_r = realized_r
                idea.closed_at = datetime.now(timezone.utc).isoformat()

                # Update equity
                eq = self._read_equity()
                pnl = idea.risk_amount * realized_r if idea.risk_amount else 0.0
                eq["current"] += pnl
                eq["daily_pnl"] = eq.get("daily_pnl", 0.0) + (pnl / eq["starting"] * 100)
                if eq["current"] > eq.get("peak", eq["current"]):
                    eq["peak"] = eq["current"]
                self._write_equity(eq)

                self._rewrite_all(ideas)
                return idea
        return None

    def load_ideas(self) -> List[Idea]:
        if not self.ideas_file.exists():
            return []
        ideas = []
        with open(self.ideas_file, "r") as f:
            for line in f:
                if line.strip():
                    d = json.loads(line)
                    # tuple restoration
                    if "entry_zone" in d and isinstance(d["entry_zone"], list):
                        d["entry_zone"] = tuple(d["entry_zone"])
                    ideas.append(Idea(**d))
        return ideas

    def _append(self, idea: Idea):
        with open(self.ideas_file, "a") as f:
            f.write(json.dumps(idea.to_dict()) + "\n")

    def _rewrite_all(self, ideas: List[Idea]):
        with open(self.ideas_file, "w") as f:
            for idea in ideas:
                f.write(json.dumps(idea.to_dict()) + "\n")

    def summary(self) -> Dict[str, Any]:
        ideas = self.load_ideas()
        closed = [i for i in ideas if i.status == "closed" and i.realized_r is not None]
        open_ = [i for i in ideas if i.status == "open"]
        total_r = sum(i.realized_r for i in closed) if closed else 0.0
        wins = sum(1 for i in closed if i.realized_r > 0)
        losses = sum(1 for i in closed if i.realized_r <= 0)
        win_rate = (wins / len(closed) * 100) if closed else 0.0
        eq = self._read_equity()

        return {
            "equity": eq["current"],
            "starting_equity": eq["starting"],
            "peak": eq.get("peak", eq["current"]),
            "open_ideas": len(open_),
            "closed_ideas": len(closed),
            "total_r": round(total_r, 2),
            "win_rate": round(win_rate, 1),
            "wins": wins,
            "losses": losses,
            "avg_r": round(total_r / len(closed), 2) if closed else 0.0,
        }