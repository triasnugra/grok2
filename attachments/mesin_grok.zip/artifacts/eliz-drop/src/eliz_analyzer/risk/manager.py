"""
Risk Manager – Real Money Protection Layer
==========================================
Enforces strict position sizing, max concurrent ideas,
daily loss limits, and ATR-based stops.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone

import numpy as np
import pandas as pd


@dataclass
class PositionSize:
    symbol: str
    direction: str
    entry_price: float
    stop_price: float
    risk_amount: float          # in quote currency (USDT)
    position_size: float        # in base currency
    position_value: float       # in USDT
    risk_pct: float
    stop_distance_pct: float
    tp1_price: float
    tp2_price: float
    r_multiple_tp1: float
    r_multiple_tp2: float


@dataclass
class RiskState:
    equity: float
    open_ideas: int
    total_risk_pct: float
    daily_pnl_pct: float
    can_open_new: bool
    reason: str = ""


class RiskManager:
    """
    Strict risk controls for real-money readiness.
    Default: 0.75% risk per trade, max 4 open ideas, max 7 day hold.
    """

    def __init__(self, cfg: dict):
        risk_cfg = cfg.get("risk", {})
        self.risk_per_trade_pct = float(risk_cfg.get("risk_per_trade_pct", 0.75))
        self.max_open_ideas = int(risk_cfg.get("max_open_ideas", 4))
        self.max_hold_days = int(risk_cfg.get("max_hold_days", 7))
        self.max_daily_loss_pct = float(risk_cfg.get("max_daily_loss_pct", 3.0))
        self.max_total_exposure_pct = float(risk_cfg.get("max_total_exposure_pct", 6.0))

        stop_cfg = risk_cfg.get("stop", {})
        self.atr_period = int(stop_cfg.get("atr_period", 14))
        self.atr_mult_min = float(stop_cfg.get("atr_multiplier_min", 1.8))
        self.atr_mult_max = float(stop_cfg.get("atr_multiplier_max", 3.5))
        self.max_stop_pct = float(stop_cfg.get("max_stop_pct", 8.0))
        self.min_stop_pct = float(stop_cfg.get("min_stop_pct", 1.2))

        tp_cfg = risk_cfg.get("take_profit", {})
        self.tp1_r = float(tp_cfg.get("tp1_r", 1.5))
        self.tp1_size_pct = float(tp_cfg.get("tp1_size_pct", 40))
        self.tp2_r = float(tp_cfg.get("tp2_r", 2.5))
        self.tp2_size_pct = float(tp_cfg.get("tp2_size_pct", 30))
        self.runner_size_pct = float(tp_cfg.get("runner_size_pct", 30))

    def atr(self, df: pd.DataFrame, period: Optional[int] = None) -> float:
        period = period or self.atr_period
        high = df["high"]
        low = df["low"]
        close = df["close"]
        tr = pd.concat(
            [
                high - low,
                (high - close.shift()).abs(),
                (low - close.shift()).abs(),
            ],
            axis=1,
        ).max(axis=1)
        return float(tr.rolling(period, min_periods=1).mean().iloc[-1])

    def calculate_stop(
        self,
        df: pd.DataFrame,
        entry_price: float,
        direction: str,
        structure_invalidation: Optional[float] = None,
    ) -> float:
        """
        Calculate stop price using ATR with hard min/max caps.
        Prefer structure invalidation if it is within acceptable ATR range.
        """
        atr_val = self.atr(df)
        atr_dist = atr_val * self.atr_mult_min

        # Convert to %
        atr_pct = (atr_dist / entry_price) * 100
        atr_pct = max(self.min_stop_pct, min(self.max_stop_pct, atr_pct))

        if direction == "long":
            atr_stop = entry_price * (1 - atr_pct / 100)
            if structure_invalidation is not None and structure_invalidation < entry_price:
                # Use the tighter (higher) of the two for long
                return max(atr_stop, structure_invalidation)
            return atr_stop
        else:
            atr_stop = entry_price * (1 + atr_pct / 100)
            if structure_invalidation is not None and structure_invalidation > entry_price:
                return min(atr_stop, structure_invalidation)
            return atr_stop

    def size_position(
        self,
        equity: float,
        entry_price: float,
        stop_price: float,
        direction: str,
        symbol: str = "",
    ) -> PositionSize:
        """
        Fixed fractional position sizing.
        Risk amount = equity * risk_per_trade_pct / 100
        """
        risk_amount = equity * (self.risk_per_trade_pct / 100.0)
        stop_distance = abs(entry_price - stop_price)

        if stop_distance <= 0:
            raise ValueError("Stop distance must be > 0")

        position_size = risk_amount / stop_distance
        position_value = position_size * entry_price
        stop_distance_pct = (stop_distance / entry_price) * 100

        # R-multiple targets
        r = stop_distance
        if direction == "long":
            tp1 = entry_price + self.tp1_r * r
            tp2 = entry_price + self.tp2_r * r
        else:
            tp1 = entry_price - self.tp1_r * r
            tp2 = entry_price - self.tp2_r * r

        return PositionSize(
            symbol=symbol,
            direction=direction,
            entry_price=entry_price,
            stop_price=stop_price,
            risk_amount=risk_amount,
            position_size=position_size,
            position_value=position_value,
            risk_pct=self.risk_per_trade_pct,
            stop_distance_pct=stop_distance_pct,
            tp1_price=tp1,
            tp2_price=tp2,
            r_multiple_tp1=self.tp1_r,
            r_multiple_tp2=self.tp2_r,
        )

    def check_can_open(
        self,
        equity: float,
        open_ideas: int,
        current_total_risk_pct: float,
        daily_pnl_pct: float,
    ) -> RiskState:
        """Gatekeeper before any new idea is accepted."""
        if open_ideas >= self.max_open_ideas:
            return RiskState(
                equity=equity,
                open_ideas=open_ideas,
                total_risk_pct=current_total_risk_pct,
                daily_pnl_pct=daily_pnl_pct,
                can_open_new=False,
                reason=f"Max open ideas reached ({self.max_open_ideas})",
            )

        if daily_pnl_pct <= -self.max_daily_loss_pct:
            return RiskState(
                equity=equity,
                open_ideas=open_ideas,
                total_risk_pct=current_total_risk_pct,
                daily_pnl_pct=daily_pnl_pct,
                can_open_new=False,
                reason=f"Daily loss limit hit ({daily_pnl_pct:.2f}% <= -{self.max_daily_loss_pct}%)",
            )

        projected_risk = current_total_risk_pct + self.risk_per_trade_pct
        if projected_risk > self.max_total_exposure_pct:
            return RiskState(
                equity=equity,
                open_ideas=open_ideas,
                total_risk_pct=current_total_risk_pct,
                daily_pnl_pct=daily_pnl_pct,
                can_open_new=False,
                reason=f"Total exposure would exceed {self.max_total_exposure_pct}%",
            )

        return RiskState(
            equity=equity,
            open_ideas=open_ideas,
            total_risk_pct=current_total_risk_pct,
            daily_pnl_pct=daily_pnl_pct,
            can_open_new=True,
            reason="OK",
        )