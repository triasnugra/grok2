"""Chart helpers – optional on serverless (matplotlib may be absent)."""
from __future__ import annotations
from typing import List, Optional

def plot_analysis(*args, **kwargs):
    try:
        import matplotlib
        matplotlib.use("Agg")
        # full implementation would go here; on Vercel we skip charts
        print("Chart skipped (matplotlib not critical on serverless)")
    except ImportError:
        print("matplotlib not installed – chart skipped")
