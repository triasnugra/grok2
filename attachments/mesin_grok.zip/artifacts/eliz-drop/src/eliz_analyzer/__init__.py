"""
EliZ Analyzer package – lazy imports to keep serverless cold-start light.
"""
__version__ = "1.1.2"
__author__ = "EliZ Analyzer Contributors"

# Do NOT import heavy modules at package level.
# Import from submodules directly, e.g.:
#   from eliz_analyzer.core.analyzer import EliZAnalyzer

__all__ = [
    "EliZAnalyzer",
    "MondayRangeCalculator",
    "BoxDetector",
    "PatternDetector",
    "RiskManager",
    "PaperJournal",
    "SignalGenerator",
]

def __getattr__(name):
    if name == "EliZAnalyzer":
        from .core.analyzer import EliZAnalyzer
        return EliZAnalyzer
    if name == "MondayRangeCalculator":
        from .core.monday_range import MondayRangeCalculator
        return MondayRangeCalculator
    if name == "BoxDetector":
        from .core.levels import BoxDetector
        return BoxDetector
    if name == "PatternDetector":
        from .core.patterns import PatternDetector
        return PatternDetector
    if name == "RiskManager":
        from .risk.manager import RiskManager
        return RiskManager
    if name == "PaperJournal":
        from .paper.journal import PaperJournal
        return PaperJournal
    if name == "SignalGenerator":
        from .signals.generator import SignalGenerator
        return SignalGenerator
    raise AttributeError(name)
