# EliZ Price Action Analyzer – Real-Money Ready Edition

**Professional crypto analysis engine based on the public methodology of @eliz883 (EliZ)**  
+ Strict Risk Management + Paper Trading Journal

> “Strategy gets you in. Discipline makes you money. Risk management keeps you in the market.”  
> — @eliz883

---

## ⚠️ CRITICAL DISCLAIMER

This software is **educational only**.

- Cryptocurrency trading involves **substantial risk of loss**.
- You can lose **all** of your capital.
- Past results (even in paper trading) **do not** guarantee future performance.
- Always start with **paper trading** for at least 1–2 months.
- Never risk more than you can afford to lose.
- The authors accept **no liability** for any financial losses incurred.

**If you are not prepared to lose money, do not trade.**

---

## What This Engine Does

| Component              | Description |
|------------------------|-----------|
| Monday Range           | Automatic High/Low of every Monday (UTC) |
| 3-Box Detector         | Supply / Mid / Demand zones on higher TF |
| Sweep + Deviation + Reclaim | Exact EliZ trigger logic |
| Risk Manager           | 0.75% risk/trade, max 4 ideas, max 7 days hold |
| ATR Stops              | 1.8–3.5× ATR with hard 1.2–8% caps |
| R-Multiple Targets     | TP1 40% @ 1.5R, TP2 30% @ 2.5R, 30% runner |
| Paper Journal          | Full audit trail of every idea |
| CLI + Streamlit        | Ready for daily workflow |

---

## Installation

```bash
git clone https://github.com/YOUR_USERNAME/eliz883-analyzer.git
cd eliz883-analyzer

python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

pip install -r requirements.txt
pip install -e .
```

---

## Daily Workflow (Recommended)

```bash
# 1. Generate risk-managed ideas (after daily close preferred)
eliz-analyzer ideas -s BTC/USDT -s ETH/USDT -s SOL/USDT

# 2. Review pending ideas
eliz-analyzer paper list --status pending

# 3. When price reaches your entry zone, open the paper trade
eliz-analyzer paper open <idea_id> <entry_price>

# 4. Later close it
eliz-analyzer paper close <idea_id> <exit_price> --reason tp1

# 5. Check performance
eliz-analyzer paper summary
```

### Single symbol analysis (no sizing)

```bash
eliz-analyzer analyze BTC/USDT --chart --save-chart ./output/btc.png
```

### Philosophy reminder

```bash
eliz-analyzer philosophy
```

---

## Risk Rules (Hard-coded defaults)

- Risk per trade: **0.75%** of equity
- Max concurrent ideas: **4**
- Max hold time: **7 days**
- Daily loss limit: **3%** → stop trading that day
- Stop: ATR-based (1.8–3.5×) with 1.2–8% hard caps
- Take Profit:
  - 40% of size at **1.5R**
  - 30% of size at **2.5R**
  - 30% runner

All values are configurable in `config/default.yaml`.

---

## Project Structure

```
eliz883-analyzer/
├── config/default.yaml
├── src/eliz_analyzer/
│   ├── core/           # Monday Range, Boxes, Patterns, Analyzer
│   ├── risk/           # Position sizing & risk gates
│   ├── paper/          # Journal & equity tracking
│   ├── signals/        # Idea generator
│   ├── visualization/
│   └── cli.py
├── app_streamlit.py
├── examples/
└── tests/
```

---

## Going Live (Only after proven paper results)

1. Paper trade for a minimum of 50–100 closed trades.
2. Verify positive expectancy and emotional control.
3. Start with the **smallest** possible real size.
4. Never increase risk above the configured limits.
5. Keep the same rules hash – do not change rules mid-stream.

The engine itself does **not** place live orders.  
You must manually execute (or integrate your own exchange connector with extreme caution).

---

## License

MIT License

---

## Credits

- Original methodology: **@eliz883 (EliZ)** on X
- Implementation: Community educational project

**Trade with discipline. Protect capital first.**
