"""
Vercel Python Entrypoint – EliZ Analyzer API (hardened)
=======================================================
Minimal, defensive FastAPI app for Vercel serverless.
Heavy analysis is imported only when /analyze is called.
"""

from __future__ import annotations

import os
import sys
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

# ── Make package importable on Vercel ────────────────────────
ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

os.environ.setdefault("ELIZ_CONFIG", str(ROOT / "config" / "default.yaml"))

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel

app = FastAPI(
    title="EliZ Price Action Analyzer",
    description=(
        "Educational crypto analysis based on @eliz883 methodology. "
        "NOT FINANCIAL ADVICE. Trading involves substantial risk of loss."
    ),
    version="1.1.1",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class HealthResponse(BaseModel):
    status: str = "ok"
    version: str = "1.1.1"
    rules_hash: str = "eliz-h2.1-20261022"
    python: str = ""
    path_ok: bool = False


class AnalyzeResponse(BaseModel):
    symbol: str
    current_price: float
    recommendation: str
    position_vs_range: str
    position_vs_boxes: str
    monday_range: Optional[Dict[str, Any]] = None
    boxes: List[Dict[str, Any]] = []
    setups: List[Dict[str, Any]] = []
    notes: List[str] = []
    disclaimer: str = (
        "Educational only. Not financial advice. "
        "Cryptocurrency trading involves substantial risk of loss."
    )


def _try_import_analyzer():
    try:
        from eliz_analyzer.core.analyzer import EliZAnalyzer
        cfg_path = os.environ.get("ELIZ_CONFIG")
        if cfg_path and Path(cfg_path).exists():
            return EliZAnalyzer(config_path=cfg_path), None
        return EliZAnalyzer(), None
    except Exception as e:
        return None, f"{type(e).__name__}: {e}\n{traceback.format_exc()}"


@app.get("/", response_class=HTMLResponse)
async def root():
    return """<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>EliZ Analyzer</title>
<style>
body{font-family:system-ui,sans-serif;max-width:720px;margin:40px auto;padding:0 20px;background:#0f0f0f;color:#e0e0e0}
h1{color:#26a69a}a{color:#42a5f5}
.warn{background:#3e2723;border-left:4px solid #ef5350;padding:12px 16px;margin:20px 0}
code{background:#1e1e1e;padding:2px 6px;border-radius:4px}
</style></head><body>
<h1>EliZ Price Action Analyzer</h1>
<p>Educational engine based on public methodology of <strong>@eliz883</strong>.</p>
<div class="warn"><strong>⚠️ DISCLAIMER</strong><br>
Not financial advice. Crypto trading involves substantial risk of loss.
Always paper-trade first.</div>
<h2>Endpoints</h2>
<ul>
<li><a href="/docs">/docs</a> – Swagger UI</li>
<li><a href="/health">/health</a> – Health check</li>
<li><code>GET /analyze?symbol=BTC/USDT</code></li>
<li><a href="/philosophy">/philosophy</a></li>
</ul>
<p style="opacity:.6;margin-top:40px;font-size:.9em">
Strategy gets you in. Discipline makes you money. Risk management keeps you in the market.
</p></body></html>"""


@app.get("/health", response_model=HealthResponse)
async def health():
    import sys as _sys
    path_ok = (ROOT / "src" / "eliz_analyzer").exists()
    return HealthResponse(
        status="ok",
        python=_sys.version.split()[0],
        path_ok=path_ok,
    )


@app.get("/analyze", response_model=AnalyzeResponse)
async def analyze(
    symbol: str = Query("BTC/USDT", description="e.g. BTC/USDT"),
    higher_tf: str = Query("1w"),
    entry_tf: str = Query("4h"),
    limit: int = Query(300, ge=50, le=800),
):
    analyzer, err = _try_import_analyzer()
    if err or analyzer is None:
        raise HTTPException(status_code=500, detail=f"Failed to load analyzer: {err}")

    sym = symbol.upper().strip()
    if "/" not in sym:
        sym = f"{sym}/USDT"

    try:
        result = analyzer.analyze(
            symbol=sym,
            higher_tf=higher_tf,
            entry_tf=entry_tf,
            limit=limit,
        )
        return AnalyzeResponse(
            symbol=result.symbol,
            current_price=result.current_price,
            recommendation=result.recommendation,
            position_vs_range=result.position_vs_range,
            position_vs_boxes=result.position_vs_boxes,
            monday_range=result.monday_range.to_dict() if result.monday_range else None,
            boxes=[b.to_dict() for b in result.boxes],
            setups=[s.to_dict() for s in result.setups],
            notes=result.notes,
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Analysis error: {type(e).__name__}: {e}",
        )


@app.get("/philosophy")
async def philosophy():
    return {
        "core": [
            "Strategy gets you in. Discipline makes you money. Risk management keeps you in the market.",
            "Entry is only 1% of the game.",
            "Never chase price. Without a clear trigger → do nothing.",
            "Sitting on hands is also a position.",
            "Triggers: Liquidity Sweep + Deviation + Reclaim.",
            "Middle of the range = No-Trade Zone.",
        ],
        "risk_rules": {
            "risk_per_trade_pct": 0.75,
            "max_open_ideas": 4,
            "max_hold_days": 7,
            "daily_loss_limit_pct": 3.0,
        },
        "disclaimer": "Educational only. Not financial advice.",
    }


@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={
            "error": type(exc).__name__,
            "detail": str(exc),
            "hint": "Check /health first. If path_ok=false the package was not found.",
        },
    )
