"""
EliZ (@eliz883) Price Action Analysis Engine – Real-Money Ready
==============================================================

Professional crypto analysis + strict risk management + paper journal
based on the public trading philosophy of Italian trader EliZ (@eliz883).

DISCLAIMER: Educational software only. Trading involves substantial risk of loss.
Never risk money you cannot afford to lose. Always paper-trade first.
"""

__version__ = "1.1.0"
__author__ = "EliZ Analyzer Contributors"

from .core.analyzer import EliZAnalyzer
from .core.monday_range import MondayRangeCalculator
from .core.levels import BoxDetector
from .core.patterns import PatternDetector
from .risk.manager import RiskManager
from .paper.journal import PaperJournal
from .signals.generator import SignalGenerator

__all__ = [
    "EliZAnalyzer",
    "MondayRangeCalculator",
    "BoxDetector",
    "PatternDetector",
    "RiskManager",
    "PaperJournal",
    "SignalGenerator",
]
