"""Root ASGI entrypoint for automatic detection."""
from api.index import app
