/**
 * EliZ Price Action Engine (browser)
 * ==================================
 * Implements public methodology of @eliz883:
 * - Monday Range (High/Low of Monday UTC)
 * - Higher-TF style boxes (swing zones)
 * - Liquidity Sweep + Deviation + Reclaim
 * - No-trade in middle of range
 *
 * Data: Binance public klines API (no key required)
 */

const EliZ = (() => {
  const BINANCE = "https://api.binance.com/api/v3/klines";

  /** Fetch OHLCV from Binance */
  async function fetchKlines(symbol, interval, limit = 300) {
    const url = `${BINANCE}?symbol=${encodeURIComponent(symbol)}&interval=${interval}&limit=${limit}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Binance API ${res.status}: ${await res.text()}`);
    const raw = await res.json();
    return raw.map((k) => ({
      time: k[0],
      open: +k[1],
      high: +k[2],
      low: +k[3],
      close: +k[4],
      volume: +k[5],
      date: new Date(k[0]),
    }));
  }

  /** Monday 00:00 UTC of the week containing ts */
  function mondayUTC(ts) {
    const d = new Date(ts);
    const day = d.getUTCDay(); // 0 Sun … 1 Mon
    const diff = day === 0 ? -6 : 1 - day;
    const m = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + diff));
    return m.getTime();
  }

  /** Calculate Monday Range from 1h (or finer) candles */
  function calcMondayRange(candles) {
    if (!candles.length) return null;
    // Group by Monday start
    const groups = new Map();
    for (const c of candles) {
      const key = mondayUTC(c.time);
      if (!groups.has(key)) groups.set(key, []);
      // Only Monday bars (UTC weekday === 1)
      if (c.date.getUTCDay() === 1) groups.get(key).push(c);
    }
    const keys = [...groups.keys()].sort((a, b) => a - b);
    // Prefer current/last week that has Monday data
    for (let i = keys.length - 1; i >= 0; i--) {
      const bars = groups.get(keys[i]);
      if (!bars || !bars.length) continue;
      let high = -Infinity, low = Infinity;
      for (const b of bars) {
        if (b.high > high) high = b.high;
        if (b.low < low) low = b.low;
      }
      return {
        weekStart: keys[i],
        high,
        low,
        mid: (high + low) / 2,
        size: high - low,
        sizePct: low > 0 ? ((high - low) / low) * 100 : 0,
      };
    }
    return null;
  }

  /** ATR */
  function atr(candles, period = 14) {
    if (candles.length < 2) return 0;
    const trs = [];
    for (let i = 1; i < candles.length; i++) {
      const h = candles[i].high, l = candles[i].low, pc = candles[i - 1].close;
      trs.push(Math.max(h - l, Math.abs(h - pc), Math.abs(l - pc)));
    }
    const slice = trs.slice(-period);
    return slice.reduce((a, b) => a + b, 0) / slice.length;
  }

  /** Simple swing boxes (supply / mid / demand) */
  function detectBoxes(candles, maxBoxes = 3) {
    if (candles.length < 20) return [];
    const left = 3, right = 3;
    const swings = [];
    for (let i = left; i < candles.length - right; i++) {
      let isHigh = true, isLow = true;
      for (let j = i - left; j <= i + right; j++) {
        if (j === i) continue;
        if (candles[j].high >= candles[i].high) isHigh = false;
        if (candles[j].low <= candles[i].low) isLow = false;
      }
      if (isHigh) swings.push({ price: candles[i].high, kind: "supply", i });
      if (isLow) swings.push({ price: candles[i].low, kind: "demand", i });
    }
    if (!swings.length) return [];

    const a = atr(candles);
    const zone = a * 0.45;
    // Cluster
    swings.sort((x, y) => y.price - x.price);
    const used = new Set();
    const clusters = [];
    for (let i = 0; i < swings.length; i++) {
      if (used.has(i)) continue;
      const c = [swings[i]];
      used.add(i);
      for (let j = i + 1; j < swings.length; j++) {
        if (used.has(j)) continue;
        if (Math.abs(swings[i].price - swings[j].price) <= zone * 2) {
          c.push(swings[j]);
          used.add(j);
        }
      }
      clusters.push(c);
    }

    let boxes = clusters.map((c) => {
      const prices = c.map((x) => x.price);
      const kinds = c.map((x) => x.kind);
      const top = Math.max(...prices) + zone * 0.4;
      const bottom = Math.min(...prices) - zone * 0.4;
      const kind = kinds.filter((k) => k === "supply").length >= kinds.length / 2 ? "supply" : "demand";
      return { top, bottom, mid: (top + bottom) / 2, kind, strength: c.length };
    });

    boxes.sort((a, b) => b.strength - a.strength);
    boxes = boxes.slice(0, maxBoxes);
    boxes.sort((a, b) => b.top - a.top);

    if (boxes.length >= 3) {
      boxes[0].kind = "supply"; boxes[0].label = "Supply / Resistance";
      boxes[1].kind = "mid"; boxes[1].label = "Mid / No-Trade";
      boxes[2].kind = "demand"; boxes[2].label = "Demand / Support";
    } else if (boxes.length === 2) {
      boxes[0].kind = "supply"; boxes[0].label = "Supply / Resistance";
      boxes[1].kind = "demand"; boxes[1].label = "Demand / Support";
    } else if (boxes.length === 1) {
      boxes[0].label = "Key Level";
    }
    return boxes;
  }

  /** Detect sweep + reclaim vs a level */
  function detectSweepReclaim(candles, level, direction, lookback = 40) {
    const recent = candles.slice(-lookback);
    if (recent.length < 5) return null;
    const minPen = 0.08; // %

    if (direction === "below") {
      // Long: sweep under level then close back above
      let sweepIdx = -1, sweepPrice = 0;
      for (let i = 0; i < recent.length; i++) {
        if (recent[i].low < level) {
          const pen = ((level - recent[i].low) / level) * 100;
          if (pen >= minPen) {
            sweepIdx = i;
            sweepPrice = recent[i].low;
          }
        }
      }
      if (sweepIdx < 0) return null;
      for (let i = sweepIdx; i < recent.length; i++) {
        if (recent[i].close > level) {
          const barsOut = i - sweepIdx;
          if (barsOut > 8) return null;
          return {
            type: "sweep_below_reclaim",
            level,
            sweepPrice,
            reclaimPrice: recent[i].close,
            penetrationPct: ((level - sweepPrice) / level) * 100,
            barsOutside: barsOut,
          };
        }
      }
    } else {
      // Short: sweep above then close back below
      let sweepIdx = -1, sweepPrice = 0;
      for (let i = 0; i < recent.length; i++) {
        if (recent[i].high > level) {
          const pen = ((recent[i].high - level) / level) * 100;
          if (pen >= minPen) {
            sweepIdx = i;
            sweepPrice = recent[i].high;
          }
        }
      }
      if (sweepIdx < 0) return null;
      for (let i = sweepIdx; i < recent.length; i++) {
        if (recent[i].close < level) {
          const barsOut = i - sweepIdx;
          if (barsOut > 8) return null;
          return {
            type: "sweep_above_reclaim",
            level,
            sweepPrice,
            reclaimPrice: recent[i].close,
            penetrationPct: ((sweepPrice - level) / level) * 100,
            barsOutside: barsOut,
          };
        }
      }
    }
    return null;
  }

  function positionVsRange(price, mr) {
    if (!mr) return "No Monday Range";
    if (price > mr.high) return "ABOVE Monday High";
    if (price < mr.low) return "BELOW Monday Low";
    const dist = Math.abs(price - mr.mid) / mr.size;
    if (dist < 0.28) return "INSIDE Monday Range — middle (no-trade zone)";
    return "INSIDE Monday Range (near extreme)";
  }

  function positionVsBoxes(price, boxes) {
    if (!boxes.length) return "No boxes";
    for (const b of boxes) {
      if (price >= b.bottom && price <= b.top) return `Inside ${b.label || b.kind}`;
    }
    const hi = Math.max(...boxes.map((b) => b.top));
    const lo = Math.min(...boxes.map((b) => b.bottom));
    if (price > hi) return "Above all boxes";
    if (price < lo) return "Below all boxes";
    return "Between boxes (middle of nowhere)";
  }

  /** Full analysis */
  async function analyze(symbol, entryInterval = "4h") {
    // Normalize symbol
    let sym = symbol.replace("/", "").toUpperCase();
    if (!sym.endsWith("USDT") && !sym.endsWith("BUSD")) sym += "USDT";

    // Parallel fetch
    const [entry, hourly, daily] = await Promise.all([
      fetchKlines(sym, entryInterval, 250),
      fetchKlines(sym, "1h", 500),
      fetchKlines(sym, "1d", 120),
    ]);

    const price = entry[entry.length - 1].close;
    const mr = calcMondayRange(hourly);
    const boxes = detectBoxes(daily.length >= 30 ? daily : entry, 3);

    const setups = [];
    const notes = [];

    // Monday Range setups
    if (mr) {
      const longSig = detectSweepReclaim(entry, mr.low, "below");
      if (longSig) {
        let score = 70 + Math.min(20, longSig.penetrationPct * 8);
        if (longSig.barsOutside <= 3) score += 10;
        setups.push({
          direction: "long",
          score: Math.min(100, Math.round(score)),
          reason: "Sweep Monday Low + Reclaim (classic EliZ long)",
          entryLow: mr.low,
          entryHigh: mr.low + mr.size * 0.15,
          invalidation: longSig.sweepPrice * 0.998,
          target: mr.high,
          details: longSig,
        });
      }
      const shortSig = detectSweepReclaim(entry, mr.high, "above");
      if (shortSig) {
        let score = 70 + Math.min(20, shortSig.penetrationPct * 8);
        if (shortSig.barsOutside <= 3) score += 10;
        setups.push({
          direction: "short",
          score: Math.min(100, Math.round(score)),
          reason: "Breakout Monday High + Deviation + Reclaim (classic EliZ short)",
          entryLow: mr.high - mr.size * 0.15,
          entryHigh: mr.high,
          invalidation: shortSig.sweepPrice * 1.002,
          target: mr.low,
          details: shortSig,
        });
      }
    }

    // Box setups
    for (const b of boxes) {
      if (b.kind === "demand") {
        const s = detectSweepReclaim(entry, b.bottom, "below");
        if (s) {
          setups.push({
            direction: "long",
            score: Math.min(95, 65 + b.strength * 3),
            reason: `Sweep + Reclaim Demand Box (${b.label})`,
            entryLow: b.bottom,
            entryHigh: b.mid,
            invalidation: s.sweepPrice * 0.997,
            target: null,
            details: s,
          });
        }
      }
      if (b.kind === "supply") {
        const s = detectSweepReclaim(entry, b.top, "above");
        if (s) {
          setups.push({
            direction: "short",
            score: Math.min(95, 65 + b.strength * 3),
            reason: `Deviation + Reclaim Supply Box (${b.label})`,
            entryLow: b.mid,
            entryHigh: b.top,
            invalidation: s.sweepPrice * 1.003,
            target: null,
            details: s,
          });
        }
      }
    }

    setups.sort((a, b) => b.score - a.score);

    const posRange = positionVsRange(price, mr);
    const posBoxes = positionVsBoxes(price, boxes);

    // Recommendation (EliZ strict)
    let recommendation = "NO TRADE — Sitting on hands";
    let recClass = "none";

    const inMiddle =
      posRange.includes("middle") ||
      posBoxes.includes("middle") ||
      posBoxes.includes("Between");

    if (inMiddle) {
      recommendation = "NO TRADE — Middle of nowhere";
      notes.push("Harga di tengah range / antara boxes. EliZ: sitting on hands is also a position.");
    }

    const good = setups.filter((s) => s.score >= 72);
    if (good.length && !inMiddle) {
      const best = good[0];
      recommendation = `POTENTIAL ${best.direction.toUpperCase()} — Score ${best.score}`;
      recClass = best.direction;
      notes.push(best.reason);
      notes.push(`Entry zone: ${fmt(best.entryLow)} – ${fmt(best.entryHigh)}`);
      notes.push(`Invalidation: ${fmt(best.invalidation)}`);
      if (best.target) notes.push(`Target hint: ${fmt(best.target)}`);
    } else if (!good.length) {
      notes.push("Tidak ada Sweep + Deviation + Reclaim yang jelas.");
      notes.push("Tunggu harga ke level kunci + reaction.");
    }

    notes.push("Strategy gets you in. Discipline makes you money. Risk management keeps you in the market.");
    notes.push("Risk saran: ≤ 0.75% equity / trade · max 4 ide · max hold 7 hari.");

    return {
      symbol: sym,
      price,
      recommendation,
      recClass,
      posRange,
      posBoxes,
      mondayRange: mr,
      boxes,
      setups,
      notes,
      candles: entry,
    };
  }

  function fmt(n) {
    if (n == null || Number.isNaN(n)) return "—";
    if (n >= 1000) return n.toLocaleString("en-US", { maximumFractionDigits: 2 });
    if (n >= 1) return n.toFixed(4);
    return n.toPrecision(4);
  }

  /** Draw simple candle chart with levels */
  function drawChart(canvas, candles, mr, boxes) {
    const ctx = canvas.getContext("2d");
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth;
    const h = canvas.height;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, w, h);

    const data = candles.slice(-80);
    if (data.length < 2) return;

    let min = Infinity, max = -Infinity;
    for (const c of data) {
      min = Math.min(min, c.low);
      max = Math.max(max, c.high);
    }
    if (mr) {
      min = Math.min(min, mr.low);
      max = Math.max(max, mr.high);
    }
    const pad = (max - min) * 0.08 || 1;
    min -= pad;
    max += pad;

    const y = (p) => h - ((p - min) / (max - min)) * (h - 16) - 8;
    const xStep = w / data.length;

    // Boxes
    for (const b of boxes || []) {
      ctx.fillStyle =
        b.kind === "supply" ? "rgba(248,81,73,0.12)" :
        b.kind === "demand" ? "rgba(63,185,80,0.12)" :
        "rgba(240,136,62,0.10)";
      ctx.fillRect(0, y(b.top), w, y(b.bottom) - y(b.top));
    }

    // Monday lines
    if (mr) {
      ctx.strokeStyle = "#f0883e";
      ctx.setLineDash([5, 4]);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, y(mr.high));
      ctx.lineTo(w, y(mr.high));
      ctx.moveTo(0, y(mr.low));
      ctx.lineTo(w, y(mr.low));
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Candles
    data.forEach((c, i) => {
      const x = i * xStep + xStep * 0.15;
      const bw = Math.max(1, xStep * 0.7);
      const up = c.close >= c.open;
      ctx.strokeStyle = up ? "#3fb950" : "#f85149";
      ctx.fillStyle = up ? "#3fb950" : "#f85149";
      ctx.beginPath();
      ctx.moveTo(x + bw / 2, y(c.high));
      ctx.lineTo(x + bw / 2, y(c.low));
      ctx.stroke();
      const top = y(Math.max(c.open, c.close));
      const bot = y(Math.min(c.open, c.close));
      ctx.fillRect(x, top, bw, Math.max(1, bot - top));
    });
  }

  return { analyze, fmt, drawChart, fetchKlines };
})();
