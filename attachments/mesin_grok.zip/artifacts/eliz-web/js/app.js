/**
 * UI controller for EliZ Analyzer
 */
(function () {
  const $ = (id) => document.getElementById(id);

  const statusEl = $("status");
  const resultsEl = $("results");
  const btn = $("btnAnalyze");

  function showStatus(msg, type) {
    statusEl.textContent = msg;
    statusEl.className = "status " + (type || "loading");
    statusEl.classList.remove("hidden");
  }
  function hideStatus() {
    statusEl.classList.add("hidden");
  }

  async function runAnalyze() {
    let symbol = $("customSymbol").value.trim() || $("symbol").value;
    const entryTf = $("entryTf").value;

    btn.disabled = true;
    resultsEl.classList.add("hidden");
    showStatus("Mengambil data Binance & menghitung Monday Range, Boxes, Sweep…", "loading");

    try {
      const r = await EliZ.analyze(symbol, entryTf);
      hideStatus();
      render(r);
      resultsEl.classList.remove("hidden");
      resultsEl.scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (e) {
      console.error(e);
      showStatus("Error: " + (e.message || e), "error");
    } finally {
      btn.disabled = false;
    }
  }

  function render(r) {
    $("outSymbol").textContent = r.symbol.replace("USDT", "/USDT");
    $("outPrice").textContent = EliZ.fmt(r.price);
    $("outPriceSub").textContent = new Date().toLocaleString("id-ID");

    const rec = $("outRec");
    rec.textContent = r.recommendation;
    rec.className = "rec " + (r.recClass || "none");

    $("outPosRange").textContent = r.posRange;
    $("outPosBoxes").textContent = r.posBoxes;

    // Monday Range
    if (r.mondayRange) {
      const m = r.mondayRange;
      $("mrHigh").textContent = EliZ.fmt(m.high);
      $("mrLow").textContent = EliZ.fmt(m.low);
      $("mrMid").textContent = EliZ.fmt(m.mid);
      $("mrSize").textContent = m.sizePct.toFixed(2) + "%";
    } else {
      $("mrHigh").textContent = "—";
      $("mrLow").textContent = "—";
      $("mrMid").textContent = "—";
      $("mrSize").textContent = "—";
    }

    // Boxes
    const boxEl = $("outBoxes");
    if (!r.boxes.length) {
      boxEl.innerHTML = '<p class="muted">Tidak cukup swing untuk boxes.</p>';
    } else {
      boxEl.innerHTML = r.boxes
        .map(
          (b) => `
        <div class="box-row ${b.kind}">
          <span class="label">${b.label || b.kind}</span>
          <span class="range">${EliZ.fmt(b.bottom)} – ${EliZ.fmt(b.top)}</span>
        </div>`
        )
        .join("");
    }

    // Setups
    const setupEl = $("outSetups");
    if (!r.setups.length) {
      setupEl.innerHTML = '<p class="muted">Tidak ada setup Sweep + Reclaim saat ini. Tunggu trigger.</p>';
    } else {
      setupEl.innerHTML = r.setups
        .map(
          (s) => `
        <div class="setup ${s.direction}">
          <div class="setup-head">
            <span class="badge ${s.direction}">${s.direction}</span>
            <span class="score">Score ${s.score}</span>
          </div>
          <div class="setup-reason">${s.reason}</div>
          <div class="setup-meta">
            <div>Entry: <b>${EliZ.fmt(s.entryLow)} – ${EliZ.fmt(s.entryHigh)}</b></div>
            <div>Invalidation: <b>${EliZ.fmt(s.invalidation)}</b></div>
            ${s.target != null ? `<div>Target hint: <b>${EliZ.fmt(s.target)}</b></div>` : ""}
          </div>
        </div>`
        )
        .join("");
    }

    // Notes
    $("outNotes").innerHTML = r.notes.map((n) => `<li>${n}</li>`).join("");

    // Chart
    requestAnimationFrame(() => {
      EliZ.drawChart($("chart"), r.candles, r.mondayRange, r.boxes);
    });
  }

  // Events
  btn.addEventListener("click", runAnalyze);
  $("customSymbol").addEventListener("keydown", (e) => {
    if (e.key === "Enter") runAnalyze();
  });

  // Philosophy modal
  const modal = $("modal");
  $("btnPhilosophy").addEventListener("click", () => modal.classList.remove("hidden"));
  $("modalClose").addEventListener("click", () => modal.classList.add("hidden"));
  modal.addEventListener("click", (e) => {
    if (e.target === modal) modal.classList.add("hidden");
  });

  // Auto-analyze BTC on load
  runAnalyze();
})();
