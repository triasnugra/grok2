import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analyze-DiqDDxqY.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function atr(candles, period = 14) {
	if (candles.length < 2) return 0;
	const trs = [];
	for (let i = 1; i < candles.length; i++) {
		const h = candles[i].high;
		const l = candles[i].low;
		const pc = candles[i - 1].close;
		trs.push(Math.max(h - l, Math.abs(h - pc), Math.abs(l - pc)));
	}
	const slice = trs.slice(-period);
	return slice.reduce((a, b) => a + b, 0) / slice.length;
}
function mondayUTC(ts) {
	const d = new Date(ts);
	const day = d.getUTCDay();
	const diff = day === 0 ? -6 : 1 - day;
	return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + diff);
}
function calcMondayRange(candles) {
	const groups = /* @__PURE__ */ new Map();
	for (const c of candles) {
		if (new Date(c.time).getUTCDay() !== 1) continue;
		const key = mondayUTC(c.time);
		const arr = groups.get(key) ?? [];
		arr.push(c);
		groups.set(key, arr);
	}
	const keys = [...groups.keys()].sort((a, b) => a - b);
	for (let i = keys.length - 1; i >= 0; i--) {
		const bars = groups.get(keys[i]);
		if (!bars.length) continue;
		let high = -Infinity;
		let low = Infinity;
		for (const b of bars) {
			if (b.high > high) high = b.high;
			if (b.low < low) low = b.low;
		}
		return {
			weekStart: keys[i],
			high,
			low,
			mid: (high + low) / 2,
			size: high - low,
			sizePct: low > 0 ? (high - low) / low * 100 : 0
		};
	}
	return null;
}
function detectBoxes(candles, maxBoxes = 3) {
	if (candles.length < 20) return [];
	const left = 3;
	const right = 3;
	const swings = [];
	for (let i = left; i < candles.length - right; i++) {
		let isHigh = true;
		let isLow = true;
		for (let j = i - left; j <= i + right; j++) {
			if (j === i) continue;
			if (candles[j].high >= candles[i].high) isHigh = false;
			if (candles[j].low <= candles[i].low) isLow = false;
		}
		if (isHigh) swings.push({
			price: candles[i].high,
			kind: "supply"
		});
		if (isLow) swings.push({
			price: candles[i].low,
			kind: "demand"
		});
	}
	if (!swings.length) return [];
	const zone = atr(candles) * .45 || candles[candles.length - 1].close * .004;
	swings.sort((a, b) => b.price - a.price);
	const used = /* @__PURE__ */ new Set();
	const clusters = [];
	for (let i = 0; i < swings.length; i++) {
		if (used.has(i)) continue;
		const c = [swings[i]];
		used.add(i);
		for (let j = i + 1; j < swings.length; j++) {
			if (used.has(j)) continue;
			if (Math.abs(swings[i].price - swings[j].price) <= zone * 2) {
				c.push(swings[j]);
				used.add(j);
			}
		}
		clusters.push(c);
	}
	let boxes = clusters.map((c) => {
		const prices = c.map((x) => x.price);
		const supplies = c.filter((x) => x.kind === "supply").length;
		const top = Math.max(...prices) + zone * .4;
		const bottom = Math.min(...prices) - zone * .4;
		const kind = supplies >= c.length / 2 ? "supply" : "demand";
		return {
			top,
			bottom,
			mid: (top + bottom) / 2,
			kind,
			label: kind,
			strength: c.length
		};
	});
	boxes.sort((a, b) => b.strength - a.strength);
	boxes = boxes.slice(0, maxBoxes);
	boxes.sort((a, b) => b.top - a.top);
	if (boxes.length >= 3) {
		boxes[0] = {
			...boxes[0],
			kind: "supply",
			label: "Supply / resistance"
		};
		boxes[1] = {
			...boxes[1],
			kind: "mid",
			label: "Mid / no-trade"
		};
		boxes[2] = {
			...boxes[2],
			kind: "demand",
			label: "Demand / support"
		};
	} else if (boxes.length === 2) {
		boxes[0] = {
			...boxes[0],
			kind: "supply",
			label: "Supply / resistance"
		};
		boxes[1] = {
			...boxes[1],
			kind: "demand",
			label: "Demand / support"
		};
	} else if (boxes.length === 1) boxes[0] = {
		...boxes[0],
		label: "Key level"
	};
	return boxes;
}
function detectSweep(candles, level, direction, lookback = 40) {
	const recent = candles.slice(-lookback);
	const minPen = .08;
	if (direction === "below") {
		let sweepIdx = -1;
		let sweepPrice = 0;
		for (let i = 0; i < recent.length; i++) if (recent[i].low < level) {
			if ((level - recent[i].low) / level * 100 >= minPen) {
				sweepIdx = i;
				sweepPrice = recent[i].low;
			}
		}
		if (sweepIdx < 0) return null;
		for (let i = sweepIdx; i < recent.length; i++) if (recent[i].close > level) {
			const barsOut = i - sweepIdx;
			if (barsOut > 8) return null;
			return {
				sweepPrice,
				pen: (level - sweepPrice) / level * 100,
				barsOut
			};
		}
	} else {
		let sweepIdx = -1;
		let sweepPrice = 0;
		for (let i = 0; i < recent.length; i++) if (recent[i].high > level) {
			if ((recent[i].high - level) / level * 100 >= minPen) {
				sweepIdx = i;
				sweepPrice = recent[i].high;
			}
		}
		if (sweepIdx < 0) return null;
		for (let i = sweepIdx; i < recent.length; i++) if (recent[i].close < level) {
			const barsOut = i - sweepIdx;
			if (barsOut > 8) return null;
			return {
				sweepPrice,
				pen: (sweepPrice - level) / level * 100,
				barsOut
			};
		}
	}
	return null;
}
function analyzeMarket(args) {
	const { symbol, source, entry, hourly, daily } = args;
	const price = entry[entry.length - 1]?.close ?? 0;
	const mr = calcMondayRange(hourly);
	const boxes = detectBoxes(daily.length >= 30 ? daily : entry, 3);
	const setups = [];
	const notes = [];
	if (mr) {
		const longSig = detectSweep(entry, mr.low, "below");
		if (longSig) {
			const stop = longSig.sweepPrice * .998;
			setups.push({
				direction: "long",
				score: Math.min(100, Math.round(70 + Math.min(20, longSig.pen * 8) + (longSig.barsOut <= 3 ? 10 : 0))),
				reason: "Sweep Monday Low lalu reclaim ke dalam range.",
				entryLow: mr.low,
				entryHigh: mr.low + mr.size * .15,
				invalidation: stop,
				target: mr.high,
				riskPct: price ? Math.abs(price - stop) / price * 100 : 0
			});
		}
		const shortSig = detectSweep(entry, mr.high, "above");
		if (shortSig) {
			const stop = shortSig.sweepPrice * 1.002;
			setups.push({
				direction: "short",
				score: Math.min(100, Math.round(70 + Math.min(20, shortSig.pen * 8) + (shortSig.barsOut <= 3 ? 10 : 0))),
				reason: "Break Monday High, deviation, lalu kembali masuk range.",
				entryLow: mr.high - mr.size * .15,
				entryHigh: mr.high,
				invalidation: stop,
				target: mr.low,
				riskPct: price ? Math.abs(stop - price) / price * 100 : 0
			});
		}
	}
	for (const b of boxes) {
		if (b.kind === "demand") {
			const s = detectSweep(entry, b.bottom, "below");
			if (s) setups.push({
				direction: "long",
				score: Math.min(95, 65 + b.strength * 3),
				reason: `Sweep + reclaim di ${b.label}.`,
				entryLow: b.bottom,
				entryHigh: b.mid,
				invalidation: s.sweepPrice * .997,
				target: null,
				riskPct: price ? Math.abs(price - s.sweepPrice) / price * 100 : 0
			});
		}
		if (b.kind === "supply") {
			const s = detectSweep(entry, b.top, "above");
			if (s) setups.push({
				direction: "short",
				score: Math.min(95, 65 + b.strength * 3),
				reason: `Deviation + reclaim di ${b.label}.`,
				entryLow: b.mid,
				entryHigh: b.top,
				invalidation: s.sweepPrice * 1.003,
				target: null,
				riskPct: price ? Math.abs(s.sweepPrice - price) / price * 100 : 0
			});
		}
	}
	setups.sort((a, b) => b.score - a.score);
	let posRange = "Tidak ada Monday Range";
	if (mr) {
		if (price > mr.high) posRange = "Di atas Monday High";
		else if (price < mr.low) posRange = "Di bawah Monday Low";
		else if (Math.abs(price - mr.mid) / mr.size < .28) posRange = "Di dalam range, dekat tengah — no-trade";
		else posRange = "Di dalam range, dekat ekstrem";
	}
	let posBoxes = "Tidak ada box";
	if (boxes.length) {
		const inside = boxes.find((b) => price >= b.bottom && price <= b.top);
		if (inside) posBoxes = `Di dalam ${inside.label}`;
		else {
			const hi = Math.max(...boxes.map((b) => b.top));
			const lo = Math.min(...boxes.map((b) => b.bottom));
			if (price > hi) posBoxes = "Di atas semua box";
			else if (price < lo) posBoxes = "Di bawah semua box";
			else posBoxes = "Di antara box — middle of nowhere";
		}
	}
	const inMiddle = posRange.includes("tengah") || posBoxes.includes("antara") || posBoxes.includes("Mid");
	let recommendation = "NO TRADE — duduk diam";
	let recClass = "none";
	if (inMiddle) {
		recommendation = "NO TRADE — tengah range";
		notes.push("Harga di tengah range. Sitting on hands is also a position.");
	}
	const good = setups.filter((s) => s.score >= 72);
	if (good.length && !inMiddle) {
		const best = good[0];
		recommendation = `${best.direction === "long" ? "LONG" : "SHORT"} potensial — skor ${best.score}`;
		recClass = best.direction;
		notes.push(best.reason);
	} else if (!good.length) {
		notes.push("Belum ada sweep + deviation + reclaim yang jelas.");
		notes.push("Tunggu harga datang ke Monday High/Low atau box, lalu lihat reaksi.");
	}
	notes.push("Entry hanya 1%. Disiplin dan risk management yang menentukan.");
	notes.push("Usulan: risk ≤ 0,75% ekuitas per ide, maksimal 4 ide, tahan paling lama 7 hari.");
	return {
		symbol,
		price,
		source,
		recommendation,
		recClass,
		posRange,
		posBoxes,
		mondayRange: mr,
		boxes,
		setups,
		notes,
		candles: entry.slice(-90)
	};
}
var INTERVALS = /* @__PURE__ */ new Set([
	"15m",
	"1h",
	"4h",
	"1d"
]);
function normSymbol(raw) {
	let s = raw.trim().toUpperCase().replace("/", "").replace("-", "");
	if (!s) s = "BTCUSDT";
	if (!/^[A-Z0-9]{4,20}$/.test(s)) throw new Error("Simbol tidak valid");
	if (!s.endsWith("USDT")) s += "USDT";
	return s;
}
function fromBinance(rows) {
	if (!Array.isArray(rows)) return [];
	return rows.map((k) => {
		const r = k;
		return {
			time: Number(r[0]),
			open: Number(r[1]),
			high: Number(r[2]),
			low: Number(r[3]),
			close: Number(r[4]),
			volume: Number(r[5])
		};
	});
}
var BYBIT_IV = {
	"15m": "15",
	"1h": "60",
	"4h": "240",
	"1d": "D"
};
function fromBybit(body) {
	return (body.result?.list ?? []).map((r) => ({
		time: Number(r[0]),
		open: Number(r[1]),
		high: Number(r[2]),
		low: Number(r[3]),
		close: Number(r[4]),
		volume: Number(r[5])
	})).reverse();
}
async function pull(url) {
	const res = await fetch(url, { headers: { accept: "application/json" } });
	if (!res.ok) throw new Error(String(res.status));
	return res.json();
}
async function klines(symbol, interval, limit) {
	for (const host of ["https://data-api.binance.vision", "https://api.binance.com"]) try {
		const candles = fromBinance(await pull(`${host}/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`));
		if (candles.length > 10) return {
			candles,
			source: host.includes("vision") ? "Binance Vision" : "Binance"
		};
	} catch {}
	const candles = fromBybit(await pull(`https://api.bybit.com/v5/market/kline?category=spot&symbol=${symbol}&interval=${BYBIT_IV[interval] ?? "60"}&limit=${Math.min(limit, 200)}`));
	if (candles.length < 10) throw new Error("Data pasar tidak tersedia untuk pair ini");
	return {
		candles,
		source: "Bybit"
	};
}
var runAnalysis_createServerFn_handler = createServerRpc({
	id: "c189dc0ca37732b914c1882ebca14128f0708e07f2fa451be858e4dc2f311c69",
	name: "runAnalysis",
	filename: "src/lib/analyze.ts"
}, (opts) => runAnalysis.__executeServer(opts));
var runAnalysis = createServerFn({ method: "GET" }).inputValidator((input) => {
	return {
		symbol: normSymbol(input.symbol ?? "BTCUSDT"),
		interval: INTERVALS.has(input.interval ?? "") ? input.interval : "4h"
	};
}).handler(runAnalysis_createServerFn_handler, async ({ data }) => {
	const [entry, hourly, daily] = await Promise.all([
		klines(data.symbol, data.interval, 250),
		klines(data.symbol, "1h", 500),
		klines(data.symbol, "1d", 120)
	]);
	return analyzeMarket({
		symbol: data.symbol,
		source: entry.source,
		entry: entry.candles,
		hourly: hourly.candles,
		daily: daily.candles
	});
});
//#endregion
export { runAnalysis_createServerFn_handler };
