import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CyQ0FRzb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var INTERVALS = /* @__PURE__ */ new Set([
	"15m",
	"1h",
	"4h",
	"1d"
]);
function normSymbol(raw) {
	let s = raw.trim().toUpperCase().replace("/", "").replace("-", "");
	if (!s) s = "BTCUSDT";
	if (!/^[A-Z0-9]{4,20}$/.test(s)) throw new Error("Simbol tidak valid");
	if (!s.endsWith("USDT")) s += "USDT";
	return s;
}
var runAnalysis = createServerFn({ method: "GET" }).inputValidator((input) => {
	return {
		symbol: normSymbol(input.symbol ?? "BTCUSDT"),
		interval: INTERVALS.has(input.interval ?? "") ? input.interval : "4h"
	};
}).handler(createSsrRpc("c189dc0ca37732b914c1882ebca14128f0708e07f2fa451be858e4dc2f311c69"));
var PAIRS = [
	"BTCUSDT",
	"ETHUSDT",
	"SOLUSDT",
	"BNBUSDT",
	"XRPUSDT",
	"ADAUSDT",
	"DOGEUSDT",
	"AVAXUSDT",
	"LINKUSDT",
	"TAOUSDT"
];
function fmt(n) {
	if (n == null || Number.isNaN(n)) return "—";
	if (n >= 1e3) return n.toLocaleString("en-US", { maximumFractionDigits: 2 });
	if (n >= 1) return n.toLocaleString("en-US", { maximumFractionDigits: 4 });
	return n.toPrecision(4);
}
function Chart({ candles, boxes, high, low }) {
	const d = (0, import_react.useMemo)(() => {
		const w = 760;
		const h = 220;
		const data = candles.slice(-80);
		if (data.length < 2) return null;
		let min = Infinity;
		let max = -Infinity;
		for (const c of data) {
			min = Math.min(min, c.low);
			max = Math.max(max, c.high);
		}
		if (high != null) max = Math.max(max, high);
		if (low != null) min = Math.min(min, low);
		const pad = (max - min) * .08 || 1;
		min -= pad;
		max += pad;
		const y = (p) => h - (p - min) / (max - min) * 204 - 8;
		const step = w / data.length;
		return {
			w,
			h,
			y,
			bars: data.map((c, i) => {
				return {
					x: i * step + step * .18,
					bw: Math.max(1.5, step * .64),
					up: c.close >= c.open,
					yH: y(c.high),
					yL: y(c.low),
					yO: y(c.open),
					yC: y(c.close)
				};
			}),
			min,
			max
		};
	}, [
		candles,
		high,
		low
	]);
	if (!d) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: `0 0 ${d.w} ${d.h}`,
		className: "h-56 w-full",
		role: "img",
		"aria-label": "Chart harga",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: d.w,
				height: d.h,
				fill: "var(--color-raised)",
				rx: "8"
			}),
			boxes.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "0",
				y: d.y(b.top),
				width: d.w,
				height: Math.max(1, d.y(b.bottom) - d.y(b.top)),
				fill: b.kind === "supply" ? "rgba(239,91,91,0.14)" : b.kind === "demand" ? "rgba(47,191,113,0.14)" : "rgba(224,160,74,0.12)"
			}, b.label + b.top)),
			high != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "0",
				x2: d.w,
				y1: d.y(high),
				y2: d.y(high),
				stroke: "var(--color-amber)",
				strokeDasharray: "5 4"
			}),
			low != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "0",
				x2: d.w,
				y1: d.y(low),
				y2: d.y(low),
				stroke: "var(--color-amber)",
				strokeDasharray: "5 4"
			}),
			d.bars.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: b.x + b.bw / 2,
				x2: b.x + b.bw / 2,
				y1: b.yH,
				y2: b.yL,
				stroke: b.up ? "var(--color-long)" : "var(--color-short)"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: b.x,
				y: Math.min(b.yO, b.yC),
				width: b.bw,
				height: Math.max(1, Math.abs(b.yC - b.yO)),
				fill: b.up ? "var(--color-long)" : "var(--color-short)"
			})] }, i))
		]
	});
}
function Home() {
	const [symbol, setSymbol] = (0, import_react.useState)("BTCUSDT");
	const [custom, setCustom] = (0, import_react.useState)("");
	const [interval, setInterval] = (0, import_react.useState)("4h");
	const [equity, setEquity] = (0, import_react.useState)("10000");
	const [showRules, setShowRules] = (0, import_react.useState)(false);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)("");
	const [data, setData] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const saved = localStorage.getItem("eliz-equity");
		if (saved) setEquity(saved);
	}, []);
	async function load(sym = symbol, iv = interval) {
		setLoading(true);
		setError("");
		try {
			const result = await runAnalysis({ data: {
				symbol: custom.trim() || sym,
				interval: iv
			} });
			setData(result);
		} catch (e) {
			setError(e instanceof Error ? e.message : "Gagal mengambil data pasar");
			setData(null);
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		load("BTCUSDT", "4h");
	}, []);
	const riskUsd = (Number(equity.replace(",", ".")) || 0) * .0075;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen max-w-3xl px-4 py-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-4 flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tracking-widest text-amber uppercase",
						children: "Price action desk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-semibold tracking-tight",
						children: "EliZ Desk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Monday Range, sweep, deviation, reclaim. Data lewat server, bukan browser."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "rounded-lg border border-line px-3 py-2 text-sm text-muted",
					onClick: () => setShowRules((v) => !v),
					children: showRules ? "Tutup aturan" : "Aturan"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 rounded-lg border border-line bg-surface px-3 py-2 text-sm text-muted",
				children: "Bukan saran keuangan. Trading crypto bisa menghabiskan modal. Paper-trade dulu. Metodologi dari catatan publik @eliz883."
			}),
			showRules && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mb-4 rounded-xl border border-line bg-surface p-4 text-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "list-decimal space-y-2 pl-5 text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Strategi hanya membawa masuk. Disiplin yang menghasilkan uang. Risk management yang menahan kamu di pasar." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Monday Range = high dan low hari Senin (UTC). Di dalam tengah range, jangan memaksa trade." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Trigger: liquidity sweep di luar level, deviation (false break), lalu reclaim." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Tiga box di timeframe tinggi: supply, tengah, demand. Level saja bukan sinyal — reaksi yang penting." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Risk kecil, invalidation jelas. Maksimal 4 ide, tahan paling lama 7 hari." })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-4 flex flex-wrap items-end gap-2 rounded-xl border border-line bg-surface p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-w-32 flex-col gap-1 text-xs text-muted",
						children: ["Pair", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "rounded-lg border border-line bg-raised px-3 py-2.5 text-sm text-fg",
							value: symbol,
							onChange: (e) => {
								setSymbol(e.target.value);
								setCustom("");
							},
							children: PAIRS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p,
								children: p.replace("USDT", "/USDT")
							}, p))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-w-28 flex-col gap-1 text-xs text-muted",
						children: ["Entry TF", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "rounded-lg border border-line bg-raised px-3 py-2.5 text-sm text-fg",
							value: interval,
							onChange: (e) => setInterval(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "15m",
									children: "15m"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "1h",
									children: "1H"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "4h",
									children: "4H"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "1d",
									children: "1D"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-w-36 flex-1 flex-col gap-1 text-xs text-muted",
						children: ["Pair lain", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "rounded-lg border border-line bg-raised px-3 py-2.5 text-sm text-fg",
							placeholder: "PEPEUSDT",
							value: custom,
							onChange: (e) => setCustom(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-w-28 flex-col gap-1 text-xs text-muted",
						children: ["Ekuitas USDT", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "rounded-lg border border-line bg-raised px-3 py-2.5 text-sm text-fg",
							inputMode: "decimal",
							value: equity,
							onChange: (e) => {
								setEquity(e.target.value);
								localStorage.setItem("eliz-equity", e.target.value);
							}
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-lg bg-long px-4 py-2.5 text-sm font-semibold text-ink disabled:opacity-60",
						disabled: loading,
						onClick: () => void load(),
						children: loading ? "Membaca pasar…" : "Analisis"
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 rounded-lg border border-short/40 bg-surface px-3 py-2 text-sm text-short",
				children: error
			}),
			data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-surface p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-xs text-muted",
								children: [
									data.symbol,
									" · ",
									data.source
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-3xl font-medium",
								children: fmt(data.price)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [
									"Risk 0,75% ≈ ",
									fmt(riskUsd),
									" USDT"
								]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `max-w-xs text-right text-lg font-semibold ${data.recClass === "long" ? "text-long" : data.recClass === "short" ? "text-short" : "text-amber"}`,
							children: data.recommendation
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-xl border border-line bg-surface p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-1 text-xs tracking-wide text-muted uppercase",
								children: "vs Monday Range"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: data.posRange })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-xl border border-line bg-surface p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-1 text-xs tracking-wide text-muted uppercase",
								children: "vs boxes"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: data.posBoxes })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl border border-line bg-surface p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-3 text-xs tracking-wide text-muted uppercase",
							children: "Monday Range"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
							children: [
								["High", data.mondayRange?.high],
								["Low", data.mondayRange?.low],
								["Mid", data.mondayRange?.mid],
								["Size", data.mondayRange ? `${data.mondayRange.sizePct.toFixed(2)}%` : null]
							].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-raised px-3 py-2 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: k
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-sm",
									children: typeof v === "number" ? fmt(v) : v ?? "—"
								})]
							}, String(k)))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl border border-line bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-3 text-xs tracking-wide text-muted uppercase",
								children: "Boxes"
							}),
							data.boxes.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Belum cukup swing untuk tiga box."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-2",
								children: data.boxes.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center justify-between rounded-lg bg-raised px-3 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: b.kind === "supply" ? "text-short" : b.kind === "demand" ? "text-long" : "text-amber",
										children: b.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-sm text-muted",
										children: [
											fmt(b.bottom),
											" – ",
											fmt(b.top)
										]
									})]
								}, b.label + b.top))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl border border-line bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-3 text-xs tracking-wide text-muted uppercase",
								children: "Setup"
							}),
							data.setups.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Tidak ada sweep + reclaim. Tunggu trigger."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-2",
								children: data.setups.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-lg border border-line p-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mb-1 flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: s.direction === "long" ? "font-semibold text-long" : "font-semibold text-short",
												children: s.direction.toUpperCase()
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono text-xs text-muted",
												children: ["skor ", s.score]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm",
											children: s.reason
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 font-mono text-xs text-muted",
											children: [
												"Entry ",
												fmt(s.entryLow),
												"–",
												fmt(s.entryHigh),
												" · SL ",
												fmt(s.invalidation),
												s.target != null ? ` · target ${fmt(s.target)}` : "",
												" · jarak stop ",
												s.riskPct.toFixed(2),
												"%"
											]
										})
									]
								}, i))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl border border-line bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-2 text-xs tracking-wide text-muted uppercase",
								children: "Chart entry"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chart, {
								candles: data.candles,
								boxes: data.boxes,
								high: data.mondayRange?.high,
								low: data.mondayRange?.low
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-muted",
								children: "Garis oranye = Monday High/Low. Merah = supply. Hijau = demand."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl border border-line bg-surface p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-2 text-xs tracking-wide text-muted uppercase",
							children: "Catatan"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "list-disc space-y-1 pl-5 text-sm text-muted",
							children: data.notes.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: n }, n))
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { Home as component };
