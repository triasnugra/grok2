//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dr8rwNC9.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DyTVBilA.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DyTVBilA.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CgRK8pAd.js"]
	}
} });
//#endregion
export { tsrStartManifest };
